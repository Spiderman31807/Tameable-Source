package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.core.BlockPos;

import net.mcreator.tameablespiders.entity.SpiderEntity;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;

public class Spider_TickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean In_Liquid = false;
		boolean In_Snow = false;
		Wall_ClimbProcedure.execute(world, x, y, z, entity);
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(MobEffects.POISON);
		if (entity instanceof SpiderEntity _datEntSetI)
			_datEntSetI.getEntityData().set(SpiderEntity.DATA_Eligible_Loot, (int) ((entity instanceof SpiderEntity _datEntI ? _datEntI.getEntityData().get(SpiderEntity.DATA_Eligible_Loot) : 0) - 1));
		if (entity instanceof CaveSpiderEntity _datEntSetI)
			_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Eligible_Loot, (int) ((entity instanceof CaveSpiderEntity _datEntI ? _datEntI.getEntityData().get(CaveSpiderEntity.DATA_Eligible_Loot) : 0) - 1));
		if (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) {
			if (entity instanceof SpiderEntity _datEntSetI)
				_datEntSetI.getEntityData().set(SpiderEntity.DATA_In_Snow, (int) ((entity instanceof SpiderEntity _datEntI ? _datEntI.getEntityData().get(SpiderEntity.DATA_In_Snow) : 0) - 1));
			if (entity instanceof CaveSpiderEntity _datEntSetI)
				_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_In_Snow, (int) ((entity instanceof CaveSpiderEntity _datEntI ? _datEntI.getEntityData().get(CaveSpiderEntity.DATA_In_Snow) : 0) - 1));
			In_Liquid = In_LiquidProcedure.execute(entity);
			In_Snow = (entity instanceof SpiderEntity _datEntI ? _datEntI.getEntityData().get(SpiderEntity.DATA_In_Snow) : 0) > 0 || (entity instanceof CaveSpiderEntity _datEntI ? _datEntI.getEntityData().get(CaveSpiderEntity.DATA_In_Snow) : 0) > 0;
			if (((entity instanceof SpiderEntity _datEntL12 && _datEntL12.getEntityData().get(SpiderEntity.DATA_Sitting)) == true
					|| (entity instanceof CaveSpiderEntity _datEntL13 && _datEntL13.getEntityData().get(CaveSpiderEntity.DATA_Sitting)) == true)
					&& ((entity instanceof SpiderEntity _datEntL14 && _datEntL14.getEntityData().get(SpiderEntity.DATA_Trying_To_Sit)) == false
							&& (entity instanceof CaveSpiderEntity _datEntL15 && _datEntL15.getEntityData().get(CaveSpiderEntity.DATA_Trying_To_Sit)) == false || In_Liquid == true || In_Snow == true)) {
				if (entity instanceof SpiderEntity _datEntSetL)
					_datEntSetL.getEntityData().set(SpiderEntity.DATA_Sitting, false);
				if (entity instanceof CaveSpiderEntity _datEntSetL)
					_datEntSetL.getEntityData().set(CaveSpiderEntity.DATA_Sitting, false);
			} else if ((entity instanceof SpiderEntity _datEntL18 && _datEntL18.getEntityData().get(SpiderEntity.DATA_Sitting)) == false
					&& (entity instanceof CaveSpiderEntity _datEntL19 && _datEntL19.getEntityData().get(CaveSpiderEntity.DATA_Sitting)) == false
					&& ((entity instanceof SpiderEntity _datEntL20 && _datEntL20.getEntityData().get(SpiderEntity.DATA_Trying_To_Sit)) == true
							|| (entity instanceof CaveSpiderEntity _datEntL21 && _datEntL21.getEntityData().get(CaveSpiderEntity.DATA_Trying_To_Sit)) == true)
					&& In_Liquid == false && In_Snow == false) {
				if (entity instanceof SpiderEntity _datEntSetL)
					_datEntSetL.getEntityData().set(SpiderEntity.DATA_Sitting, true);
				if (entity instanceof CaveSpiderEntity _datEntSetL)
					_datEntSetL.getEntityData().set(CaveSpiderEntity.DATA_Sitting, true);
				if (entity instanceof Mob _entity)
					_entity.getNavigation().moveTo(x, y, z, 0);
			}
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.POWDER_SNOW) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_In_Snow, 20);
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_In_Snow, 20);
			}
		}
	}
}

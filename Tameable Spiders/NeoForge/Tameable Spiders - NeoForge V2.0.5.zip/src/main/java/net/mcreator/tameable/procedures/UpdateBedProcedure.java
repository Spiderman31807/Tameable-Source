package net.mcreator.tameable.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.tameable.init.TameableModBlocks;

public class UpdateBedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		Direction dir = Direction.NORTH;
		BlockState lookingfor = Blocks.AIR.defaultBlockState();
		dir = (new Object() {
			public Direction getDirection(BlockState _bs) {
				Property<?> _prop = _bs.getBlock().getStateDefinition().getProperty("facing");
				if (_prop instanceof DirectionProperty _dp)
					return _bs.getValue(_dp);
				_prop = _bs.getBlock().getStateDefinition().getProperty("axis");
				return _prop instanceof EnumProperty _ep && _ep.getPossibleValues().toArray()[0] instanceof Direction.Axis ? Direction.fromAxisAndDirection((Direction.Axis) _bs.getValue(_ep), Direction.AxisDirection.POSITIVE) : Direction.NORTH;
			}
		}.getDirection(blockstate)).getOpposite();
		lookingfor = TameableModBlocks.BED_SOUTH.get().defaultBlockState();
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == TameableModBlocks.BED_SOUTH.get()) {
			dir = new Object() {
				public Direction getDirection(BlockState _bs) {
					Property<?> _prop = _bs.getBlock().getStateDefinition().getProperty("facing");
					if (_prop instanceof DirectionProperty _dp)
						return _bs.getValue(_dp);
					_prop = _bs.getBlock().getStateDefinition().getProperty("axis");
					return _prop instanceof EnumProperty _ep && _ep.getPossibleValues().toArray()[0] instanceof Direction.Axis ? Direction.fromAxisAndDirection((Direction.Axis) _bs.getValue(_ep), Direction.AxisDirection.POSITIVE) : Direction.NORTH;
				}
			}.getDirection(blockstate);
			lookingfor = TameableModBlocks.BED_NORTH.get().defaultBlockState();
		}
		if (!(GetOtherBedProcedure.execute(world, x, y, z, blockstate).getBlock() == lookingfor.getBlock())) {
			world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
			world.levelEvent(2001, BlockPos.containing(x, y, z), Block.getId(TameableModBlocks.BED_NORTH.get().defaultBlockState()));
		}
	}
}

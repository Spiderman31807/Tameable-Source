package tameable.spiders.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class spider_saddle_stand<T extends Entity> extends EntityModel<T> {
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("tameable_spiders", "spider_saddle_stand"), "main");
	public final ModelPart Saddle;

	public spider_saddle_stand(ModelPart root) {
		this.Saddle = root.getChild("Saddle");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition Saddle = partdefinition.addOrReplaceChild("Saddle", CubeListBuilder.create().texOffs(27, 5).addBox(-5.0F, 0.4F, -1.6F, 10.0F, -1.0F, 16.0F, new CubeDeformation(0.5F)), PartPose.offset(0.0F, 10.8F, 2.0F));
		PartDefinition Right_r1 = Saddle.addOrReplaceChild("Right_r1",
				CubeListBuilder.create().texOffs(24, -2).addBox(-10.0F, -5.0F, -5.0F, -1.0F, 10.0F, 10.0F, new CubeDeformation(0.5F)).texOffs(24, -2).addBox(1.0F, -5.0F, -5.0F, -1.0F, 10.0F, 10.0F, new CubeDeformation(0.5F)),
				PartPose.offsetAndRotation(5.0F, 5.4F, 5.4F, 1.5708F, 0.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 64, 32);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		Saddle.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}

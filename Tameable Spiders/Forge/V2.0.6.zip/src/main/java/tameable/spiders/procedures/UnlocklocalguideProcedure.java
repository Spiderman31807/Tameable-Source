package tameable.spiders.procedures;

import tameable.spiders.network.TameableSpidersModVariables;
import tameable.spiders.entity.CaveSpiderEntity;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import java.util.Comparator;

public class UnlocklocalguideProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate, Entity entity) {
		if (entity == null)
			return;
		Entity nearbyCaveSpider = null;
		nearbyCaveSpider = (Entity) world.getEntitiesOfClass(CaveSpiderEntity.class, AABB.ofSize(new Vec3(x, y, z), 16, 16, 16), e -> true).stream().sorted(new Object() {
			Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
				return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
			}
		}.compareDistOf(x, y, z)).findFirst().orElse(null);
		if ((nearbyCaveSpider instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) == entity && blockstate.is(BlockTags.create(new ResourceLocation("spiderman318:ore"))) && true) {
			{
				double _setval = (entity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables())).LocalGuide_Progress + 1;
				entity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.LocalGuide_Progress = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			if ((entity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables())).LocalGuide_Progress >= 30) {
				if (entity instanceof ServerPlayer _player) {
					Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("tameable_spiders:deleted_mod_element"));
					AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
					if (!_ap.isDone()) {
						for (String criteria : _ap.getRemainingCriteria())
							_player.getAdvancements().award(_adv, criteria);
					}
				}
			}
		}
	}
}

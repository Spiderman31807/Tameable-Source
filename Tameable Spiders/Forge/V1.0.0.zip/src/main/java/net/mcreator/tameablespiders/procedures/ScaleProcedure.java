package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.tameablespiders.entity.SpiderEntity;

public class ScaleProcedure {
	public static double execute(Entity entity) {
		if (entity == null)
			return 0;
		double base = 0;
		if (entity instanceof SpiderEntity) {
			base = 1;
		} else {
			base = 0.7;
		}
		return entity instanceof LivingEntity _livEnt1 && _livEnt1.isBaby() ? base * 0.5 : base;
	}
}

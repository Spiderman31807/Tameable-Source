
package tameable.spiders.client.renderer;

import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SpiderModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.Minecraft;

import tameable.spiders.entity.AbstractSpider;
import tameable.spiders.client.model.spider_sitting;
import tameable.spiders.client.model.spider_big_head;
import tameable.spiders.client.model.spider_saddle_stand;
import tameable.spiders.client.model.spider_saddle_sitting;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class SpiderRenderer extends MobRenderer<AbstractSpider, SpiderModel<AbstractSpider>> {
	public SpiderRenderer(EntityRendererProvider.Context context) {
		super(context, new SpiderModel(context.bakeLayer(ModelLayers.SPIDER)), 0.5f);

		this.addLayer(new RenderLayer<AbstractSpider, SpiderModel<AbstractSpider>>(this) {
			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, AbstractSpider entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.isBaby()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(entity.getTexture(false)));
					EntityModel model = new spider_big_head(Minecraft.getInstance().getEntityModels().bakeLayer(spider_big_head.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		
		this.addLayer(new RenderLayer<AbstractSpider, SpiderModel<AbstractSpider>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/spider_eyes.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, AbstractSpider entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.isBaby()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
					EntityModel model = new spider_big_head(Minecraft.getInstance().getEntityModels().bakeLayer(spider_big_head.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<AbstractSpider, SpiderModel<AbstractSpider>>(this) {

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, AbstractSpider entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (!entity.isSitting() && !entity.isInvisible()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(entity.getTexture(true)));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<AbstractSpider, SpiderModel<AbstractSpider>>(this) {

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, AbstractSpider entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.isSitting() && !entity.isInvisible()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(entity.getTexture(true)));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});

		this.addLayer(new RenderLayer<AbstractSpider, SpiderModel<AbstractSpider>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/pig_saddle.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, AbstractSpider entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (!entity.isSitting() && entity.hasSaddle()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_saddle_stand(Minecraft.getInstance().getEntityModels().bakeLayer(spider_saddle_stand.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<AbstractSpider, SpiderModel<AbstractSpider>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/pig_saddle.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, AbstractSpider entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.isSitting() && entity.hasSaddle()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_saddle_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_saddle_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});

		this.addLayer(new RenderLayer<AbstractSpider, SpiderModel<AbstractSpider>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/spider_eyes.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, AbstractSpider entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (!entity.isBaby()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});

		this.RenderCollar();
	}

	public void RenderCollar() {
		this.addLayer(new RenderLayer<AbstractSpider, SpiderModel<AbstractSpider>>(this) {
			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, AbstractSpider entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				float[] afloat = entity.getCollarColor().getTextureDiffuseColors();
				ResourceLocation Collar = new ResourceLocation("tameable_spiders:textures/entities/spider_collar.png");
				if (entity.isTame() && !entity.isSitting() && !entity.isInvisible()) {
					renderColoredCutoutModel(this.getParentModel(), Collar, poseStack, bufferSource, light, entity, afloat[0], afloat[1], afloat[2]);
				}
			}
		});
		
		this.addLayer(new RenderLayer<AbstractSpider, SpiderModel<AbstractSpider>>(this) {
			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, AbstractSpider entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				float[] afloat = entity.getCollarColor().getTextureDiffuseColors();
				ResourceLocation Collar = new ResourceLocation("tameable_spiders:textures/entities/spider_collar.png");
				if (entity.isTame() && entity.isSitting() && !entity.isInvisible()) {
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					
					renderColoredCutoutModel(model, Collar, poseStack, bufferSource, light, entity, afloat[0], afloat[1], afloat[2]);
				}
			}
		});
	}

	@Override
	protected void scale(AbstractSpider entity, PoseStack poseStack, float f) {
		Level world = entity.level();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		float scale = entity.GetScale();
		poseStack.scale(scale, scale, scale);
	}

	@Override
	public ResourceLocation getTextureLocation(AbstractSpider entity) {
		return entity.getTexture(false);
	}
}


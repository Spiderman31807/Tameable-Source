
package net.mcreator.tameablespiders.client.renderer;

import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SpiderModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.Minecraft;

import net.mcreator.tameablespiders.procedures.Yellow_CollarProcedure;
import net.mcreator.tameablespiders.procedures.White_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Yellow_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_White_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Red_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Purple_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Pink_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Orange_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Magenta_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Lime_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Light_Gray_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Light_Blue_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Green_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Gray_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Cyan_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Brown_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Blue_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Sitting_Black_CollarProcedure;
import net.mcreator.tameablespiders.procedures.ScaleProcedure;
import net.mcreator.tameablespiders.procedures.Red_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Purple_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Pink_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Orange_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Not_SittingProcedure;
import net.mcreator.tameablespiders.procedures.Magenta_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Lime_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Light_Gray_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Light_Blue_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Is_SittingProcedure;
import net.mcreator.tameablespiders.procedures.Is_ChildProcedure;
import net.mcreator.tameablespiders.procedures.Green_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Gray_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Cyan_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Brown_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Blue_CollarProcedure;
import net.mcreator.tameablespiders.procedures.Black_CollarProcedure;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;
import net.mcreator.tameablespiders.client.model.Modelspider_big_head;
import net.mcreator.tameablespiders.client.model.Modelspider;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class CaveSpiderRenderer extends MobRenderer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>> {
	public CaveSpiderRenderer(EntityRendererProvider.Context context) {
		super(context, new SpiderModel(context.bakeLayer(ModelLayers.SPIDER)), 0.49f);
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/cave_spider.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
				this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/spider_eyes.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
				this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/cave_spider_sit.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Is_SittingProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/cave_spider_sit.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Not_SittingProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/cave_spider.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Is_ChildProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider_big_head(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider_big_head.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/spider_eyes.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Is_ChildProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
					EntityModel model = new Modelspider_big_head(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider_big_head.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_white.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (White_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_white.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_White_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_light_gray.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Light_Gray_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_light_gray.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Light_Gray_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_gray.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Gray_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_gray.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Gray_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_black.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Black_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_black.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Black_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_red.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Red_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_red.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Red_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_orange.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Orange_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_orange.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Orange_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_yellow.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Yellow_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_yellow.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Yellow_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_lime.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Lime_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_lime.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Lime_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_green.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Green_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_green.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Green_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_brown.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Brown_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_brown.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Brown_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_pink.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Pink_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_pink.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Pink_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_magenta.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Magenta_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_magenta.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Magenta_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_purple.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Purple_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_purple.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Purple_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_blue.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Blue_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_blue.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Blue_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_cyan.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Cyan_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_cyan.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Cyan_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_light_blue.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Light_Blue_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<CaveSpiderEntity, SpiderModel<CaveSpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable_spiders:textures/entities/collar_light_blue.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, CaveSpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (Sitting_Light_Blue_CollarProcedure.execute(entity)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new Modelspider(Minecraft.getInstance().getEntityModels().bakeLayer(Modelspider.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
	}

	@Override
	protected void scale(CaveSpiderEntity entity, PoseStack poseStack, float f) {
		Level world = entity.level();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		float scale = (float) ScaleProcedure.execute(entity);
		poseStack.scale(scale, scale, scale);
	}

	@Override
	public ResourceLocation getTextureLocation(CaveSpiderEntity entity) {
		return new ResourceLocation("tameable_spiders:textures/entities/cave_spider.png");
	}
}

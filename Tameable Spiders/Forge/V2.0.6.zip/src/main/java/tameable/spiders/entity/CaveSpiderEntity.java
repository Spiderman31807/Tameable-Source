
package tameable.spiders.entity;


import net.minecraftforge.network.PlayMessages;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.EntityType;

import tameable.spiders.init.TameableSpidersModEntities;
import tameable.spiders.entity.AbstractSpider;

import javax.annotation.Nullable;

public class CaveSpiderEntity extends AbstractSpider {
	public CaveSpiderEntity(PlayMessages.SpawnEntity packet, Level world) {
		this(TameableSpidersModEntities.CAVE_SPIDER.get(), world);
	}
    
	public CaveSpiderEntity(EntityType<CaveSpiderEntity> type, Level world) {
		super(type, world);
	}
}

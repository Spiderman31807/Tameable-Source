package net.mcreator.tameablespiders.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.monster.CaveSpider;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.tameablespiders.init.TameableSpidersModGameRules;
import net.mcreator.tameablespiders.init.TameableSpidersModEntities;
import net.mcreator.tameablespiders.entity.SpiderEntity;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;
import net.mcreator.tameablespiders.TameableSpidersMod;

import javax.annotation.Nullable;

import java.util.Comparator;

@Mod.EventBusSubscriber
public class Spider_SpawnProcedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getLevel(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		Entity new_mob = null;
		double size = 0;
		double effect_strength = 0;
		double effect_speed = 0;
		double effect_regeneration = 0;
		double effect_invisibility = 0;
		double ticks_strength = 0;
		double ticks_speed = 0;
		double ticks_rengeneration = 0;
		double ticks_invisibility = 0;
		size = 4;
		if (entity instanceof SpiderEntity && entity instanceof LivingEntity _livEnt1 && _livEnt1.isBaby()
				&& !(((Entity) world.getEntitiesOfClass(SpiderEntity.class, AABB.ofSize(new Vec3(x, y, z), size, size, size), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)) == null) && (((Entity) world.getEntitiesOfClass(SpiderEntity.class, AABB.ofSize(new Vec3(x, y, z), size, size, size), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false)) {
			if (entity instanceof SpiderEntity _datEntSetL)
				_datEntSetL.getEntityData().set(SpiderEntity.DATA_Trying_To_Sit, false);
			if (entity instanceof TamableAnimal _toTame && (((Entity) world.getEntitiesOfClass(SpiderEntity.class, AABB.ofSize(new Vec3(x, y, z), size, size, size), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof Player _owner)
				_toTame.tame(_owner);
			if (entity instanceof SpiderEntity _datEntSetI)
				_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 4);
		} else if (entity instanceof CaveSpiderEntity && entity instanceof LivingEntity _livEnt12 && _livEnt12.isBaby()
				&& !(((Entity) world.getEntitiesOfClass(CaveSpiderEntity.class, AABB.ofSize(new Vec3(x, y, z), size, size, size), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)) == null) && (((Entity) world.getEntitiesOfClass(CaveSpiderEntity.class, AABB.ofSize(new Vec3(x, y, z), size, size, size), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false)) {
			if (entity instanceof CaveSpiderEntity _datEntSetL)
				_datEntSetL.getEntityData().set(CaveSpiderEntity.DATA_Trying_To_Sit, false);
			if (entity instanceof TamableAnimal _toTame && (((Entity) world.getEntitiesOfClass(CaveSpiderEntity.class, AABB.ofSize(new Vec3(x, y, z), size, size, size), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof Player _owner)
				_toTame.tame(_owner);
			if (entity instanceof CaveSpiderEntity _datEntSetI)
				_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 4);
		} else if (entity instanceof Spider && world.getLevelData().getGameRules().getBoolean(TameableSpidersModGameRules.CONFI_REPLACE) && !entity.isVehicle()) {
			effect_strength = entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.DAMAGE_BOOST) ? _livEnt.getEffect(MobEffects.DAMAGE_BOOST).getAmplifier() : 0;
			effect_speed = entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.MOVEMENT_SPEED) ? _livEnt.getEffect(MobEffects.MOVEMENT_SPEED).getAmplifier() : 0;
			effect_regeneration = entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.REGENERATION) ? _livEnt.getEffect(MobEffects.REGENERATION).getAmplifier() : 0;
			effect_invisibility = entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.INVISIBILITY) ? _livEnt.getEffect(MobEffects.INVISIBILITY).getAmplifier() : 0;
			ticks_strength = entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.DAMAGE_BOOST) ? _livEnt.getEffect(MobEffects.DAMAGE_BOOST).getDuration() : 0;
			ticks_speed = entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.MOVEMENT_SPEED) ? _livEnt.getEffect(MobEffects.MOVEMENT_SPEED).getDuration() : 0;
			ticks_rengeneration = entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.REGENERATION) ? _livEnt.getEffect(MobEffects.REGENERATION).getDuration() : 0;
			ticks_invisibility = entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.INVISIBILITY) ? _livEnt.getEffect(MobEffects.INVISIBILITY).getDuration() : 0;
			if (entity instanceof CaveSpider) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = TameableSpidersModEntities.CAVE_SPIDER.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(entity.getYRot());
						entityToSpawn.setYBodyRot(entity.getYRot());
						entityToSpawn.setYHeadRot(entity.getYRot());
						entityToSpawn.setXRot(entity.getXRot());
						entityToSpawn.setDeltaMovement(0, 0, 0);
					}
				}
				new_mob = (Entity) world.getEntitiesOfClass(CaveSpiderEntity.class, AABB.ofSize(new Vec3(x, y, z), 1, 1, 1), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null);
				TameableSpidersMod.queueServerWork(1, () -> {
					if (!entity.level().isClientSide())
						entity.discard();
				});
			} else {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = TameableSpidersModEntities.SPIDER.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(entity.getYRot());
						entityToSpawn.setYBodyRot(entity.getYRot());
						entityToSpawn.setYHeadRot(entity.getYRot());
						entityToSpawn.setXRot(entity.getXRot());
						entityToSpawn.setDeltaMovement(0, 0, 0);
					}
				}
				new_mob = (Entity) world.getEntitiesOfClass(SpiderEntity.class, AABB.ofSize(new Vec3(x, y, z), 1, 1, 1), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null);
				TameableSpidersMod.queueServerWork(1, () -> {
					if (!entity.level().isClientSide())
						entity.discard();
				});
			}
			if (new_mob instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, (int) ticks_strength, (int) effect_strength));
			if (new_mob instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, (int) ticks_speed, (int) effect_speed));
			if (new_mob instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, (int) ticks_rengeneration, (int) effect_regeneration));
			if (new_mob instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, (int) ticks_invisibility, (int) effect_invisibility));
		}
	}
}


package tameable.spiders.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AdvancementiconrootItem extends Item {
	public AdvancementiconrootItem() {
		super(new Item.Properties().stacksTo(0).rarity(Rarity.COMMON));
	}
}

package net.mcreator.tameable.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.tameable.init.TameableModBlocks;

public class GetOtherBedProcedure {
	public static BlockState execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		BlockState block = Blocks.AIR.defaultBlockState();
		Direction dir = Direction.NORTH;
		dir = new Object() {
			public Direction getDirection(BlockState _bs) {
				Property<?> _prop = _bs.getBlock().getStateDefinition().getProperty("facing");
				if (_prop instanceof DirectionProperty _dp)
					return _bs.getValue(_dp);
				_prop = _bs.getBlock().getStateDefinition().getProperty("axis");
				return _prop instanceof EnumProperty _ep && _ep.getPossibleValues().toArray()[0] instanceof Direction.Axis ? Direction.fromAxisAndDirection((Direction.Axis) _bs.getValue(_ep), Direction.AxisDirection.POSITIVE) : Direction.NORTH;
			}
		}.getDirection(blockstate);
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == TameableModBlocks.BED_NORTH.get()) {
			dir = dir.getOpposite();
		}
		if (dir == Direction.NORTH) {
			block = (world.getBlockState(BlockPos.containing(x, y, z - 1)));
		} else if (dir == Direction.SOUTH) {
			block = (world.getBlockState(BlockPos.containing(x, y, z + 1)));
		} else if (dir == Direction.WEST) {
			block = (world.getBlockState(BlockPos.containing(x - 1, y, z)));
		} else {
			block = (world.getBlockState(BlockPos.containing(x + 1, y, z)));
		}
		return block;
	}
}

package net.mcreator.tameable.procedures;

import net.minecraft.world.level.GameType;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.client.Minecraft;

import net.mcreator.tameable.entity.SpiderEntity;

public class DyeCollarProcedure {
	public static void execute(Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		double CollarType = 0;
		if (itemstack.getItem() == Items.WHITE_DYE || itemstack.getItem() == Items.BONE_MEAL) {
			CollarType = 0;
		} else if (itemstack.getItem() == Items.LIGHT_GRAY_DYE) {
			CollarType = 1;
		} else if (itemstack.getItem() == Items.GRAY_DYE) {
			CollarType = 2;
		} else if (itemstack.getItem() == Items.BLACK_DYE || itemstack.getItem() == Items.INK_SAC) {
			CollarType = 3;
		} else if (itemstack.getItem() == Items.BROWN_DYE || itemstack.getItem() == Items.COCOA_BEANS) {
			CollarType = 4;
		} else if (itemstack.getItem() == Items.RED_DYE) {
			CollarType = 5;
		} else if (itemstack.getItem() == Items.ORANGE_DYE) {
			CollarType = 6;
		} else if (itemstack.getItem() == Items.YELLOW_DYE) {
			CollarType = 7;
		} else if (itemstack.getItem() == Items.LIME_DYE) {
			CollarType = 8;
		} else if (itemstack.getItem() == Items.GREEN_DYE) {
			CollarType = 9;
		} else if (itemstack.getItem() == Items.CYAN_DYE) {
			CollarType = 10;
		} else if (itemstack.getItem() == Items.LIGHT_BLUE_DYE) {
			CollarType = 11;
		} else if (itemstack.getItem() == Items.BLUE_DYE || itemstack.getItem() == Items.LAPIS_LAZULI) {
			CollarType = 12;
		} else if (itemstack.getItem() == Items.PURPLE_DYE) {
			CollarType = 13;
		} else if (itemstack.getItem() == Items.MAGENTA_DYE) {
			CollarType = 14;
		} else if (itemstack.getItem() == Items.PINK_DYE) {
			CollarType = 15;
		} else {
			CollarType = -1;
		}
		if ((entity instanceof SpiderEntity _datEntI ? _datEntI.getEntityData().get(SpiderEntity.Collar) : 0) != CollarType) {
			if (entity instanceof SpiderEntity _datEntSetI)
				_datEntSetI.getEntityData().set(SpiderEntity.Collar, (int) CollarType);
		}
	}
}

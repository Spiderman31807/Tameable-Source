
package net.mcreator.tameablespiders.entity;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.entity.ai.goal.FollowParentGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.tags.ItemTags;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.BlockPos;

import net.mcreator.tameablespiders.procedures.Spider_TickProcedure;
import net.mcreator.tameablespiders.procedures.Spider_Right_ClickProcedure;
import net.mcreator.tameablespiders.procedures.Spider_LootProcedure;
import net.mcreator.tameablespiders.procedures.Spider_HurtProcedure;
import net.mcreator.tameablespiders.procedures.Spider_Follow_AdultProcedure;
import net.mcreator.tameablespiders.procedures.Panic_In_SnowProcedure;
import net.mcreator.tameablespiders.procedures.Not_SittingProcedure;
import net.mcreator.tameablespiders.procedures.Is_HostileProcedure;
import net.mcreator.tameablespiders.procedures.In_LiquidProcedure;
import net.mcreator.tameablespiders.procedures.FollowOwnerProcedure;
import net.mcreator.tameablespiders.procedures.CanLureProcedure;
import net.mcreator.tameablespiders.procedures.CanBreedProcedure;
import net.mcreator.tameablespiders.init.TameableSpidersModEntities;

public class SpiderEntity extends TamableAnimal {
	public static final EntityDataAccessor<Boolean> DATA_Sitting = SynchedEntityData.defineId(SpiderEntity.class, EntityDataSerializers.BOOLEAN);
	public static final EntityDataAccessor<Boolean> DATA_Trying_To_Sit = SynchedEntityData.defineId(SpiderEntity.class, EntityDataSerializers.BOOLEAN);
	public static final EntityDataAccessor<Integer> DATA_Collar_Color = SynchedEntityData.defineId(SpiderEntity.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Integer> DATA_Eligible_Loot = SynchedEntityData.defineId(SpiderEntity.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Boolean> DATA_Is_Climbing = SynchedEntityData.defineId(SpiderEntity.class, EntityDataSerializers.BOOLEAN);
	public static final EntityDataAccessor<Integer> DATA_In_Snow = SynchedEntityData.defineId(SpiderEntity.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<String> DATA_ID = SynchedEntityData.defineId(SpiderEntity.class, EntityDataSerializers.STRING);

	public SpiderEntity(PlayMessages.SpawnEntity packet, Level world) {
		this(TameableSpidersModEntities.SPIDER.get(), world);
	}

	public SpiderEntity(EntityType<SpiderEntity> type, Level world) {
		super(type, world);
		setMaxUpStep(0f);
		xpReward = 0;
		setNoAi(false);
		setPersistenceRequired();
	}

	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(DATA_Sitting, false);
		this.entityData.define(DATA_Trying_To_Sit, true);
		this.entityData.define(DATA_Collar_Color, -1);
		this.entityData.define(DATA_Eligible_Loot, 0);
		this.entityData.define(DATA_Is_Climbing, false);
		this.entityData.define(DATA_In_Snow, 0);
		this.entityData.define(DATA_ID, "");
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(1, new BreedGoal(this, 1) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && CanBreedProcedure.execute(world, entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && CanBreedProcedure.execute(world, entity);
			}
		});
		this.goalSelector.addGoal(2, new FollowParentGoal(this, 0.8) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && Spider_Follow_AdultProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && Spider_Follow_AdultProcedure.execute(entity);
			}
		});
		this.targetSelector.addGoal(3, new OwnerHurtTargetGoal(this) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && Not_SittingProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && Not_SittingProcedure.execute(entity);
			}
		});
		this.goalSelector.addGoal(4, new OwnerHurtByTargetGoal(this) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && Not_SittingProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && Not_SittingProcedure.execute(entity);
			}
		});
		this.goalSelector.addGoal(5, new RandomStrollGoal(this, 1.2) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && Panic_In_SnowProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && Panic_In_SnowProcedure.execute(entity);
			}
		});
		this.goalSelector.addGoal(6, new FollowOwnerGoal(this, 1, (float) 10, (float) 2, false) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && FollowOwnerProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && FollowOwnerProcedure.execute(entity);
			}
		});
		this.goalSelector.addGoal(7, new LeapAtTargetGoal(this, (float) 0.5) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && Not_SittingProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && Not_SittingProcedure.execute(entity);
			}
		});
		this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
		this.goalSelector.addGoal(9, new FloatGoal(this) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && In_LiquidProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && In_LiquidProcedure.execute(entity);
			}
		});
		this.targetSelector.addGoal(10, new HurtByTargetGoal(this) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && Not_SittingProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && Not_SittingProcedure.execute(entity);
			}
		});
		this.targetSelector.addGoal(11, new NearestAttackableTargetGoal(this, Player.class, true, true) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && Is_HostileProcedure.execute(world, x, y, z, entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && Is_HostileProcedure.execute(world, x, y, z, entity);
			}
		});
		this.goalSelector.addGoal(12, new MeleeAttackGoal(this, 1, false) {
			@Override
			protected double getAttackReachSqr(LivingEntity entity) {
				return this.mob.getBbWidth() * this.mob.getBbWidth() + entity.getBbWidth();
			}

			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && Not_SittingProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && Not_SittingProcedure.execute(entity);
			}

		});
		this.goalSelector.addGoal(13, new RandomStrollGoal(this, 0.8) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && Not_SittingProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && Not_SittingProcedure.execute(entity);
			}
		});
		this.goalSelector.addGoal(14, new TemptGoal(this, 1, Ingredient.of(Items.BEEF), false) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && CanLureProcedure.execute(world, entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && CanLureProcedure.execute(world, entity);
			}
		});
		this.goalSelector.addGoal(15, new TemptGoal(this, 1, Ingredient.of(Items.PORKCHOP), false) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && CanLureProcedure.execute(world, entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && CanLureProcedure.execute(world, entity);
			}
		});
		this.goalSelector.addGoal(16, new TemptGoal(this, 1, Ingredient.of(Items.MUTTON), false) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && CanLureProcedure.execute(world, entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && CanLureProcedure.execute(world, entity);
			}
		});
		this.goalSelector.addGoal(17, new TemptGoal(this, 1, Ingredient.of(Items.CHICKEN), false) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && CanLureProcedure.execute(world, entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && CanLureProcedure.execute(world, entity);
			}
		});
		this.goalSelector.addGoal(18, new TemptGoal(this, 1, Ingredient.of(Items.RABBIT), false) {
			@Override
			public boolean canUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canUse() && CanLureProcedure.execute(world, entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = SpiderEntity.this.getX();
				double y = SpiderEntity.this.getY();
				double z = SpiderEntity.this.getZ();
				Entity entity = SpiderEntity.this;
				Level world = SpiderEntity.this.level();
				return super.canContinueToUse() && CanLureProcedure.execute(world, entity);
			}
		});
	}

	@Override
	public MobType getMobType() {
		return MobType.ARTHROPOD;
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	@Override
	public SoundEvent getAmbientSound() {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.spider.ambient"));
	}

	@Override
	public void playStepSound(BlockPos pos, BlockState blockIn) {
		this.playSound(ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.spider.step")), 0.15f, 1);
	}

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.spider.hurt"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.spider.death"));
	}

	@Override
	public boolean hurt(DamageSource damagesource, float amount) {
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level();
		Entity entity = this;
		Entity sourceentity = damagesource.getEntity();
		Entity immediatesourceentity = damagesource.getDirectEntity();

		Spider_HurtProcedure.execute(damagesource, entity);
		return super.hurt(damagesource, amount);
	}

	@Override
	public void die(DamageSource source) {
		super.die(source);
		Spider_LootProcedure.execute(this.level(), this.getX(), this.getY(), this.getZ(), source, this);
	}

	@Override
	public void addAdditionalSaveData(CompoundTag compound) {
		super.addAdditionalSaveData(compound);
		compound.putBoolean("DataSitting", this.entityData.get(DATA_Sitting));
		compound.putBoolean("DataTrying_To_Sit", this.entityData.get(DATA_Trying_To_Sit));
		compound.putInt("DataCollar_Color", this.entityData.get(DATA_Collar_Color));
		compound.putInt("DataEligible_Loot", this.entityData.get(DATA_Eligible_Loot));
		compound.putBoolean("DataIs_Climbing", this.entityData.get(DATA_Is_Climbing));
		compound.putInt("DataIn_Snow", this.entityData.get(DATA_In_Snow));
		compound.putString("DataID", this.entityData.get(DATA_ID));
	}

	@Override
	public void readAdditionalSaveData(CompoundTag compound) {
		super.readAdditionalSaveData(compound);
		if (compound.contains("DataSitting"))
			this.entityData.set(DATA_Sitting, compound.getBoolean("DataSitting"));
		if (compound.contains("DataTrying_To_Sit"))
			this.entityData.set(DATA_Trying_To_Sit, compound.getBoolean("DataTrying_To_Sit"));
		if (compound.contains("DataCollar_Color"))
			this.entityData.set(DATA_Collar_Color, compound.getInt("DataCollar_Color"));
		if (compound.contains("DataEligible_Loot"))
			this.entityData.set(DATA_Eligible_Loot, compound.getInt("DataEligible_Loot"));
		if (compound.contains("DataIs_Climbing"))
			this.entityData.set(DATA_Is_Climbing, compound.getBoolean("DataIs_Climbing"));
		if (compound.contains("DataIn_Snow"))
			this.entityData.set(DATA_In_Snow, compound.getInt("DataIn_Snow"));
		if (compound.contains("DataID"))
			this.entityData.set(DATA_ID, compound.getString("DataID"));
	}

	@Override
	public InteractionResult mobInteract(Player sourceentity, InteractionHand hand) {
		ItemStack itemstack = sourceentity.getItemInHand(hand);
		InteractionResult retval = InteractionResult.sidedSuccess(this.level().isClientSide());
		Item item = itemstack.getItem();
		if (itemstack.getItem() instanceof SpawnEggItem) {
			retval = super.mobInteract(sourceentity, hand);
		} else if (this.level().isClientSide()) {
			retval = (this.isTame() && this.isOwnedBy(sourceentity) || this.isFood(itemstack)) ? InteractionResult.sidedSuccess(this.level().isClientSide()) : InteractionResult.PASS;
		} else {
			if (this.isTame()) {
				if (this.isOwnedBy(sourceentity)) {
					if (item.isEdible() && this.isFood(itemstack) && this.getHealth() < this.getMaxHealth()) {
						this.usePlayerItem(sourceentity, hand, itemstack);
						this.heal((float) item.getFoodProperties().getNutrition());
						retval = InteractionResult.sidedSuccess(this.level().isClientSide());
					} else if (this.isFood(itemstack) && this.getHealth() < this.getMaxHealth()) {
						this.usePlayerItem(sourceentity, hand, itemstack);
						this.heal(4);
						retval = InteractionResult.sidedSuccess(this.level().isClientSide());
					} else {
						retval = super.mobInteract(sourceentity, hand);
					}
				}
			} else if (this.isFood(itemstack)) {
				this.usePlayerItem(sourceentity, hand, itemstack);
				if (this.random.nextInt(3) == 0 && !net.minecraftforge.event.ForgeEventFactory.onAnimalTame(this, sourceentity)) {
					this.tame(sourceentity);
					this.level().broadcastEntityEvent(this, (byte) 7);
				} else {
					this.level().broadcastEntityEvent(this, (byte) 6);
				}
				this.setPersistenceRequired();
				retval = InteractionResult.sidedSuccess(this.level().isClientSide());
			} else {
				retval = super.mobInteract(sourceentity, hand);
				if (retval == InteractionResult.SUCCESS || retval == InteractionResult.CONSUME)
					this.setPersistenceRequired();
			}
		}
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Entity entity = this;
		Level world = this.level();

		Spider_Right_ClickProcedure.execute(entity, sourceentity);
		return retval;
	}

	@Override
	public void baseTick() {
		super.baseTick();
		Spider_TickProcedure.execute(this.level(), this.getX(), this.getY(), this.getZ(), this);
	}

	@Override
	public AgeableMob getBreedOffspring(ServerLevel serverWorld, AgeableMob ageable) {
		SpiderEntity retval = TameableSpidersModEntities.SPIDER.get().create(serverWorld);
		retval.finalizeSpawn(serverWorld, serverWorld.getCurrentDifficultyAt(retval.blockPosition()), MobSpawnType.BREEDING, null, null);
		return retval;
	}

	@Override
	public boolean isFood(ItemStack stack) {
		return Ingredient.of(ItemTags.create(new ResourceLocation("tameable_spiders:spider_food"))).test(stack);
	}

	public static void init() {
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.3);
		builder = builder.add(Attributes.MAX_HEALTH, 16);
		builder = builder.add(Attributes.ARMOR, 0);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 3);
		builder = builder.add(Attributes.FOLLOW_RANGE, 16);
		return builder;
	}
}

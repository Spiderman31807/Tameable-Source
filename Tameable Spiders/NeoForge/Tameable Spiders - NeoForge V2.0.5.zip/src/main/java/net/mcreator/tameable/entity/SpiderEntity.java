package net.mcreator.tameable.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;

import net.mcreator.tameable.entity.AbstractSpider;

public class SpiderEntity extends AbstractSpider {

	public SpiderEntity(EntityType<? extends SpiderEntity> type, Level world) {
		super(type, world);
	}

	public static void init() {
	}

	public static AttributeSupplier.Builder createAttributes() {
		return AbstractSpider.createAttributes();
	}
}
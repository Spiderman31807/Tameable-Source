package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Entity;

import net.mcreator.tameablespiders.init.TameableSpidersModGameRules;

public class CanLureProcedure {
	public static boolean execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return false;
		return world.getLevelData().getGameRules().getBoolean(TameableSpidersModGameRules.CONFI_LURE) == true && !(entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false);
	}
}

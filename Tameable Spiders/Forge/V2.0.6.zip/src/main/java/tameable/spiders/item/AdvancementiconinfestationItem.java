
package tameable.spiders.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AdvancementiconinfestationItem extends Item {
	public AdvancementiconinfestationItem() {
		super(new Item.Properties().stacksTo(0).rarity(Rarity.COMMON));
	}
}

package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

public class IsHudTargetProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return false;
		Entity return_entity = null;
		return !(HudTargetProcedure.execute(world, x, y, z, entity) == null);
	}
}

package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class IsSouthSoildProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return false;
		boolean is_soild = false;
		double South_Z = 0;
		BlockState South_Block = Blocks.AIR.defaultBlockState();
		is_soild = true;
		South_Z = z + entity.getBbWidth() + 0.1;
		South_Block = (world.getBlockState(BlockPos.containing(x, y, South_Z)));
		if (South_Block.getBlock() instanceof LiquidBlock || !world.getBlockState(BlockPos.containing(x, y, South_Z)).isFaceSturdy(world, BlockPos.containing(x, y, South_Z), Direction.SOUTH)) {
			is_soild = false;
		} else {
			if (South_Block.getBlock() == Blocks.POWDER_SNOW) {
				is_soild = false;
			}
		}
		return is_soild;
	}
}

package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.entity.Entity;

public class In_LiquidProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return entity.isInWaterOrBubble() || entity.isInLava();
	}
}

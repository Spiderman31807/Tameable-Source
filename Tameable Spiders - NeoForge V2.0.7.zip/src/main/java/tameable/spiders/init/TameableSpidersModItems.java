
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package tameable.spiders.init;

import tameable.spiders.item.VemonItem;
import tameable.spiders.item.SilkItem;
import tameable.spiders.item.RootIconItem;
import tameable.spiders.item.PestIconItem;
import tameable.spiders.item.ExterminatorIconItem;
import tameable.spiders.item.BedItem;
import tameable.spiders.item.AllyIconItem;
import tameable.spiders.item.AcheIconItem;
import tameable.spiders.TameableSpidersMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

public class TameableSpidersModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(TameableSpidersMod.MODID);
	public static final DeferredHolder<Item, Item> VEMON = REGISTRY.register("vemon", VemonItem::new);
	public static final DeferredHolder<Item, Item> SILK = REGISTRY.register("silk", SilkItem::new);
	public static final DeferredHolder<Item, Item> ROOT_ICON = REGISTRY.register("root_icon", RootIconItem::new);
	public static final DeferredHolder<Item, Item> ALLY_ICON = REGISTRY.register("ally_icon", AllyIconItem::new);
	public static final DeferredHolder<Item, Item> ACHE_ICON = REGISTRY.register("ache_icon", AcheIconItem::new);
	public static final DeferredHolder<Item, Item> PEST_ICON = REGISTRY.register("pest_icon", PestIconItem::new);
	public static final DeferredHolder<Item, Item> EXTERMINATOR_ICON = REGISTRY.register("exterminator_icon", ExterminatorIconItem::new);
	public static final DeferredHolder<Item, Item> BED = REGISTRY.register("bed", BedItem::new);
	public static final DeferredHolder<Item, Item> BED_NORTH = block(TameableSpidersModBlocks.BED_NORTH);
	public static final DeferredHolder<Item, Item> BED_SOUTH = block(TameableSpidersModBlocks.BED_SOUTH);
	public static final DeferredHolder<Item, Item> SILK_WEB = block(TameableSpidersModBlocks.SILK_WEB);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}

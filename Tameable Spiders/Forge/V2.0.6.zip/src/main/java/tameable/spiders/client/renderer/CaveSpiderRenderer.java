
package tameable.spiders.client.renderer;

import net.minecraft.client.renderer.entity.EntityRendererProvider;

public class CaveSpiderRenderer extends SpiderRenderer {

	public CaveSpiderRenderer(EntityRendererProvider.Context context) {
		super(context);
	}
}


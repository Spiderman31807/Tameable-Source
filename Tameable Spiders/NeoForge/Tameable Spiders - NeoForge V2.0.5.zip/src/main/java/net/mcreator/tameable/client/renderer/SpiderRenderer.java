
package net.mcreator.tameable.client.renderer;

import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SpiderModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.Minecraft;

import net.mcreator.tameable.entity.SpiderEntity;
import net.mcreator.tameable.client.model.spider_sitting;
import net.mcreator.tameable.client.model.spider_big_head;
import net.mcreator.tameable.client.model.spider_saddle_stand;
import net.mcreator.tameable.client.model.spider_saddle_sitting;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class SpiderRenderer extends MobRenderer<SpiderEntity, SpiderModel<SpiderEntity>> {

	public SpiderRenderer(EntityRendererProvider.Context context) {
		super(context, new SpiderModel(context.bakeLayer(ModelLayers.SPIDER)), 0.5f);

		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/spider.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.isBaby()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_big_head(Minecraft.getInstance().getEntityModels().bakeLayer(spider_big_head.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/spider_eyes.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.isBaby()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
					EntityModel model = new spider_big_head(Minecraft.getInstance().getEntityModels().bakeLayer(spider_big_head.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/spider_back.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (!entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/spider_back.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});

		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/pig_saddle.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (!entity.isSitting() && entity.hasSaddle()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_saddle_stand(Minecraft.getInstance().getEntityModels().bakeLayer(spider_saddle_stand.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/pig_saddle.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.isSitting() && entity.hasSaddle()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_saddle_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_saddle_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});

		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/spider_eyes.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (!entity.isBaby()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_white.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 0 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_lightgray.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 1 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_gray.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 2 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_black.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 3 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_brown.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 4 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_red.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 5 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_orange.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 6 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_yellow.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 7 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_lime.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 8 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_green.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 9 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_cyan.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 10 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_lightblue.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 11 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_blue.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 12 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_purple.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 13 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_magenta.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 14 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_pink.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 15 && !entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});

		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_white.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 0 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_lightgray.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 1 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_gray.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 2 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_black.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 3 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_brown.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 4 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_red.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 5 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_orange.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 6 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_yellow.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 7 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_lime.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 8 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_green.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 9 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_cyan.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 10 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_lightblue.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 11 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_blue.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 12 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_purple.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 13 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_magenta.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 14 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<SpiderEntity, SpiderModel<SpiderEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("tameable:textures/entities/collar_pink.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, SpiderEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (entity.getCollar() == 15 && entity.isSitting()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					EntityModel model = new spider_sitting(Minecraft.getInstance().getEntityModels().bakeLayer(spider_sitting.LAYER_LOCATION));
					this.getParentModel().copyPropertiesTo(model);
					model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
					model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
					model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
	}

	@Override
	protected void scale(SpiderEntity entity, PoseStack poseStack, float f) {
		Level world = entity.level();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		float scale = entity.GetScale();
		poseStack.scale(scale, scale, scale);
	}

	@Override
	public ResourceLocation getTextureLocation(SpiderEntity entity) {
		return new ResourceLocation("tameable:textures/entities/spider.png");
	}
}



package tameable.spiders.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;

import tameable.spiders.TameableSpidersMod;
import tameable.spiders.init.TameableSpidersModBlocks;
import tameable.spiders.block.entity.BedNorthBlockEntity;
import tameable.spiders.network.TameableSpidersModVariables;
import tameable.spiders.entity.AbstractSpider;

import javax.annotation.Nullable;
import java.util.Optional;
import java.util.UUID;

public class BedNorthBlock extends Block implements SimpleWaterloggedBlock, EntityBlock {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
	public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;
    public static final BooleanProperty ATTACHED = BlockStateProperties.ATTACHED;

	public Optional<UUID> OccupiedUUID;
	
	public BedNorthBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).mapColor(MapColor.STONE).sound(SoundType.STONE).strength(1f, 10f).requiresCorrectToolForDrops().noOcclusion().pushReaction(PushReaction.BLOCK).isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(WATERLOGGED, false).setValue(ATTACHED, false));
		OccupiedUUID = Optional.empty();
	}

	@Override
	public void destroy(LevelAccessor accessor, BlockPos pos, BlockState state) {
		OccupiedUUID.ifPresent(UUID -> {
			if(accessor instanceof ServerLevel server)
			{
				AbstractSpider spider = (AbstractSpider) server.getEntity(UUID);
    			spider.ResetHome();
			}
		});

		super.destroy(accessor, pos, state);
	}

	public void UpdateOccupied(Optional<UUID> uuid)
	{
		OccupiedUUID = uuid;
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return state.getFluidState().isEmpty();
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> box(0, 0, 0, 16, 8, 15);
			case NORTH -> box(0, 0, 1, 16, 8, 16);
			case EAST -> box(0, 0, 0, 15, 8, 16);
			case WEST -> box(1, 0, 0, 16, 8, 16);
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING, WATERLOGGED, ATTACHED);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite()).setValue(WATERLOGGED, flag).setValue(ATTACHED, Boolean.valueOf(false));
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public FluidState getFluidState(BlockState state) {
		return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
	}

	@Override
	public BlockState updateShape(BlockState state, Direction facing, BlockState facingState, LevelAccessor world, BlockPos currentPos, BlockPos facingPos) {
		if (state.getValue(WATERLOGGED)) {
			world.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(world));
		}
		return super.updateShape(state, facing, facingState, world, currentPos, facingPos);
	}

	@Override
	public ItemStack getCloneItemStack(BlockState state, HitResult target, BlockGetter world, BlockPos pos, Player player) {
		return new ItemStack(TameableSpidersModBlocks.BED_ITEM.get());
	}

	@Override
	public BlockPathTypes getBlockPathType(BlockState state, BlockGetter world, BlockPos pos, Mob entity) {
		return BlockPathTypes.WALKABLE;
	}

	@Override
	public void neighborChanged(BlockState blockstate, Level world, BlockPos pos, Block neighborBlock, BlockPos fromPos, boolean moving) {
		super.neighborChanged(blockstate, world, pos, neighborBlock, fromPos, moving);
		if(GetBedHalf(blockstate, world, pos) instanceof BedSouthBlock)
			return;

		if(((BedNorthBlockEntity) world.getBlockEntity(pos)).IsOccupied() == true)
    	{
    		AbstractSpider spider = (AbstractSpider) ((BedNorthBlockEntity) world.getBlockEntity(pos)).GetOccupied();
    		spider.ResetHome();
    	}
    	
		((LevelAccessor)world).destroyBlock(pos, false);
	}

	@Override
	public InteractionResult use(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit)
	{
    	Entity OccupiedBy = ((BedNorthBlockEntity) world.getBlockEntity(pos)).GetOccupied();
		TameableSpidersModVariables.PlayerVariables _vars = entity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables());
		

		if(entity.isShiftKeyDown())
		{
			_vars.AssignHome = blockstate;
			_vars.AssigningHome = true;
			_vars.AssignX = pos.getX();
			_vars.AssignY = pos.getY();
			_vars.AssignZ = pos.getZ();
			
			_vars.syncPlayerVariables(entity);
			return InteractionResult.PASS;
		}
		else if(canInteract(entity, hand, blockstate) == false)
		{
			if(_vars.AssigningHome == false)
			{
    			if (OccupiedBy == null) {
    	    		if (!entity.level().isClientSide())
    	        		entity.displayClientMessage(Component.literal("Spider Bed isn't Claimed"), true);
    			} else {
    			    if (!entity.level().isClientSide())
    			        entity.displayClientMessage(Component.literal(("Spider Bed Claimed by: " + OccupiedBy.getDisplayName().getString())), true);
    			}
				
				return InteractionResult.SUCCESS;
			}
			else
			{
				_vars.AssigningHome = false;
				_vars.syncPlayerVariables(entity);
				if (!entity.level().isClientSide())
					entity.displayClientMessage(Component.literal(("")), true);
					
				return InteractionResult.SUCCESS;
			}
		}
	
    	return super.use(blockstate, world, pos, entity, hand, hit);
	}

	public boolean canInteract(Player player, InteractionHand hand, BlockState state)
	{
		boolean returnValue = false;
		
		Boolean Waterlogged = state.getValue(WATERLOGGED);
		ItemStack itemstack = (hand == InteractionHand.MAIN_HAND ? player.getMainHandItem() : player.getOffhandItem());
		Item item = itemstack.getItem();


		if(item == Items.BUCKET && Waterlogged == true)
			returnValue = true;
		if(item == Items.WATER_BUCKET && Waterlogged == false)
			returnValue = true;

		return returnValue;
	}

	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new BedNorthBlockEntity(pos, state);
	}

	public void UpdateAttached(Boolean Input, Level world, BlockPos pos)
	{
		BlockState state = world.getBlockState(pos);
		if (state.getBlock().getStateDefinition().getProperty("attached") instanceof BooleanProperty property)
		{
			if(state.getValue(property) != Input)
			{
				BedNorthBlockEntity entity = (BedNorthBlockEntity) world.getBlockEntity(pos);
				Entity stored = entity.GetOccupied();
			
				world.setBlock(pos, state.setValue(property, Input), 3);
				entity = (BedNorthBlockEntity) world.getBlockEntity(pos);
				if(stored != null)
					entity.SetOccupied(stored, false);
			}

			BlockState SouthState = GetOtherHalf(state, world, pos);
			if(SouthState.getBlock() instanceof BedSouthBlock SouthBlock)
				SouthBlock.UpdateAttached(Input, world, GetOtherPos(pos, state));
		}
	}

	public BedSouthBlock GetBedHalf(BlockState state, Level world, BlockPos pos)
	{
		Block OtherHalf = GetOtherHalf(state, world, pos).getBlock();
		if(OtherHalf instanceof BedSouthBlock Bed)
			return Bed;
		return null;
	}

	public BlockPos GetOtherPos(BlockPos pos, BlockState state)
	{
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		
		Direction dir = getDirection(state);
		
		if (dir == Direction.NORTH) {
			z++;
		} else if (dir == Direction.SOUTH) {
			z--;
		} else if (dir == Direction.WEST) {
			x++;
		} else {
			x--;
		}

		return BlockPos.containing(x, y, z);
	}

	public BlockState GetOtherHalf(BlockState state, Level world, BlockPos pos)
	{
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		
		Direction dir = getDirection(state);
		
		if (dir == Direction.NORTH) {
			z++;
		} else if (dir == Direction.SOUTH) {
			z--;
		} else if (dir == Direction.WEST) {
			x++;
		} else {
			x--;
		}
		
		return world.getBlockState(BlockPos.containing(x, y, z));
	}

	public Direction getDirection(BlockState state) {
		Property<?> facing = state.getBlock().getStateDefinition().getProperty("facing");
		if (facing instanceof DirectionProperty dir)
			return state.getValue(dir);
		facing = state.getBlock().getStateDefinition().getProperty("axis");
		return facing instanceof EnumProperty _ep && _ep.getPossibleValues().toArray()[0] instanceof Direction.Axis ? Direction.fromAxisAndDirection((Direction.Axis) state.getValue(_ep), Direction.AxisDirection.POSITIVE) : Direction.NORTH;
	}
}
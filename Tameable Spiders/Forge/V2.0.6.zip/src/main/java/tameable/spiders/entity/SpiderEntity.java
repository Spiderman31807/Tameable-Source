package tameable.spiders.entity;

import net.minecraftforge.network.PlayMessages;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

import tameable.spiders.init.TameableSpidersModEntities;
import tameable.spiders.entity.AbstractSpider;

public class SpiderEntity extends AbstractSpider {
	public SpiderEntity(PlayMessages.SpawnEntity packet, Level world) {
		this(TameableSpidersModEntities.SPIDER.get(), world);
	}

	public SpiderEntity(EntityType<? extends SpiderEntity> type, Level world) {
		super(type, world);
	}
}
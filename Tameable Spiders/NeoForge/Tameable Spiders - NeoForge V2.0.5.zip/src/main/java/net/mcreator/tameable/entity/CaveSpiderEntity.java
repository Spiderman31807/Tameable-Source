
package net.mcreator.tameable.entity;

import org.joml.Vector3f;

import net.minecraft.world.Difficulty;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.tameable.init.TameableRules;
import net.mcreator.tameable.init.TameableModEntities;
import net.mcreator.tameable.init.TameableModItems;

import javax.annotation.Nullable;

public class CaveSpiderEntity extends SpiderEntity {
    
	public CaveSpiderEntity(EntityType<CaveSpiderEntity> type, Level world) {
		super(type, world);
	}

	@Override
    public boolean doHurtTarget(Entity entity) {
        if (super.doHurtTarget(entity)) {
            if (entity instanceof LivingEntity target && (!this.isBaby() || this.level().getLevelData().getGameRules().getBoolean(TameableRules.BABY_POISON)))
            {
                if (this.level().getDifficulty() == Difficulty.NORMAL) {
                    target.addEffect(new MobEffectInstance(MobEffects.POISON, 140, 0), this);
                } else if (this.level().getDifficulty() == Difficulty.HARD) {
                    target.addEffect(new MobEffectInstance(MobEffects.POISON, 300, 0), this);
                }
            }

            return true;
        } else {
            return false;
        }
    }

    @Override
    public float GetScale()
    {
    	float value = this.isBaby() ? 0.35F : 0.7F;
    	return value;
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        return (this.isBaby()) ? 0.225F : 0.45F;
    }

    @Override
    protected Vector3f getPassengerAttachmentPoint(Entity entity, EntityDimensions dimensions, float f) {
        return new Vector3f(0.0F, dimensions.height, 0.0F);
    }

    @Override
    protected float ridingOffset(Entity entity) {
        return entity.getBbWidth() <= this.getBbWidth() ? -0.21875F : 0.0F;
    }

	@Override
	public boolean CanHarvest(Item item) {
		return !this.isBaby() && item == Items.GLASS_BOTTLE && this.level().getLevelData().getGameRules().getBoolean(TameableRules.PRODUCE_VEMON);
	}
	
	@Override
	public void Harvest(Level world, double x, double y, double z, Player sourceentity, InteractionHand hand, ItemStack itemstack) {
        itemstack.shrink(1);
		sourceentity.getInventory().add(new ItemStack(TameableModItems.VEMON));
		world.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("entity.cow.milk")), SoundSource.NEUTRAL, 1, 1);
	}

	@Override
	public EntityDimensions getDimensions(Pose pose) {
		return super.getDimensions(pose).scale(0.55f);
	}

	public static void init() {
	}

	public static AttributeSupplier.Builder createAttributes() {
		return SpiderEntity.createAttributes().add(Attributes.MAX_HEALTH, 12);
	}
}

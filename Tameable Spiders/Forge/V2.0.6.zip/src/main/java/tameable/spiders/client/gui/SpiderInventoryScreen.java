package tameable.spiders.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.AgeableMob;

import tameable.spiders.world.inventory.SpiderInventoryMenu;
import tameable.spiders.network.SpiderInventoryButtonMessage;
import tameable.spiders.TameableSpidersMod;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class SpiderInventoryScreen extends AbstractContainerScreen<SpiderInventoryMenu> {
	private final static HashMap<String, Object> guistate = SpiderInventoryMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	public Entity boundEntity = null;
	ImageButton imagebutton_saddle;

	public SpiderInventoryScreen(SpiderInventoryMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.boundEntity = container.boundEntity;
		this.imageWidth = 176;
		this.imageHeight = 176;
	}

	private static final ResourceLocation texture = new ResourceLocation("tameable_spiders:textures/screens/spider_inventory.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		InventoryScreen.renderEntityInInventoryFollowsAngle(guiGraphics, this.leftPos + 60, this.topPos + 55, 30, 0f + (float) Math.atan((this.leftPos + 60 - mouseX) / 40.0), (float) Math.atan((this.topPos + 33 - mouseY) / 40.0), (LivingEntity) this.boundEntity);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(texture, this.leftPos, this.topPos - 5, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);

		guiGraphics.blit(new ResourceLocation("tameable_spiders:textures/screens/saddle_outline.png"), this.leftPos + 8, this.topPos + 26, 0, 0, 16, 16, 16, 16);
		guiGraphics.blit(new ResourceLocation("tameable_spiders:textures/screens/string.png"), this.leftPos + 8, this.topPos + 44, 0, 0, 16, 16, 16, 16);
		
   		int yPos = this.topPos + 71;
		float health = ((LivingEntity) this.boundEntity).getHealth();
		int maxHealth = (int) ((LivingEntity) this.boundEntity).getMaxHealth();
		double maxHearts = maxHealth * 0.5;
		boolean EvenHP = maxHearts == Math.floor(maxHearts);
		int MiddleX = this.leftPos + (EvenHP ? 78 : 74);
		
		for (int i = 2; i < maxHealth + 2; i += 2) {
    		int xPos = MiddleX - (maxHealth * 5) / 2 + (i * 5);
    		String Heart = "heart_outline";
		
    		if(health > i - 2)
    			Heart = "heart_half";
    		if(health > i - 1)
    			Heart = "heart_full";
  				
  			guiGraphics.blit(new ResourceLocation("tameable_spiders:textures/screens/" + Heart + ".png"), xPos, yPos, 0, 0, 9, 9, 9, 9);
		}

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
	}

	@Override
	public void init() {
		super.init();
		imagebutton_saddle = new ImageButton(this.leftPos + 8, this.topPos + 5, 16, 16, 0, 0, 16, new ResourceLocation("tameable_spiders:textures/screens/atlas/imagebutton_saddle.png"), 16, 32, e -> {
			if (true) {
				TameableSpidersMod.PACKET_HANDLER.sendToServer(new SpiderInventoryButtonMessage(0, x, y, z));
				SpiderInventoryButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		});
		guistate.put("button:imagebutton_saddle", imagebutton_saddle);
		this.addRenderableWidget(imagebutton_saddle);
	}
}

package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.tameablespiders.entity.SpiderEntity;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;

public class Is_SittingProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		boolean output = false;
		if (entity instanceof SpiderEntity) {
			output = entity instanceof SpiderEntity _datEntL1 && _datEntL1.getEntityData().get(SpiderEntity.DATA_Sitting);
		} else {
			output = entity instanceof CaveSpiderEntity _datEntL2 && _datEntL2.getEntityData().get(CaveSpiderEntity.DATA_Sitting);
		}
		return output;
	}
}

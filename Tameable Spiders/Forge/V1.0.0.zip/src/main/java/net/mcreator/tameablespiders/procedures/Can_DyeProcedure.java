package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

public class Can_DyeProcedure {
	public static boolean execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return false;
		boolean logic = false;
		Entity hand_of = null;
		logic = false;
		hand_of = sourceentity;
		if (((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.INK_SAC || (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BLACK_DYE)
				&& !(Black_CollarProcedure.execute(entity) || Sitting_Black_CollarProcedure.execute(entity))
				|| ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BONE_MEAL
						|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.WHITE_DYE) && !(White_CollarProcedure.execute(entity) || Sitting_White_CollarProcedure.execute(entity))
				|| ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LAPIS_LAZULI
						|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BLUE_DYE) && !(Blue_CollarProcedure.execute(entity) || Sitting_Blue_CollarProcedure.execute(entity))
				|| ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.COCOA_BEANS
						|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BROWN_DYE) && !(Brown_CollarProcedure.execute(entity) || Sitting_Brown_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LIGHT_BLUE_DYE && !(Light_Blue_CollarProcedure.execute(entity) || Sitting_Light_Blue_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LIGHT_GRAY_DYE && !(Light_Gray_CollarProcedure.execute(entity) || Sitting_Light_Gray_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.GRAY_DYE && !(Gray_CollarProcedure.execute(entity) || Sitting_Gray_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.CYAN_DYE && !(Cyan_CollarProcedure.execute(entity) || Sitting_Cyan_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.GREEN_DYE && !(Green_CollarProcedure.execute(entity) || Sitting_Green_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.PINK_DYE && !(Pink_CollarProcedure.execute(entity) || Sitting_Pink_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.RED_DYE && !(Red_CollarProcedure.execute(entity) || Sitting_Red_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.PURPLE_DYE && !(Purple_CollarProcedure.execute(entity) || Sitting_Purple_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.MAGENTA_DYE && !(Magenta_CollarProcedure.execute(entity) || Sitting_Magenta_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LIME_DYE && !(Lime_CollarProcedure.execute(entity) || Sitting_Lime_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.YELLOW_DYE && !(Yellow_CollarProcedure.execute(entity) || Sitting_Yellow_CollarProcedure.execute(entity))
				|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.ORANGE_DYE && !(Orange_CollarProcedure.execute(entity) || Sitting_Orange_CollarProcedure.execute(entity))) {
			logic = true;
		}
		return logic;
	}
}

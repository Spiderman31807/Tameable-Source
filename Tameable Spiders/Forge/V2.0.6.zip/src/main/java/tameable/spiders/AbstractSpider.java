package tameable.spiders.entity;

import org.joml.Vector3f;
import java.util.Comparator;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.concurrent.atomic.AtomicReference;

import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.items.wrapper.EntityHandsInvWrapper;
import net.minecraftforge.items.wrapper.EntityArmorInvWrapper;
import net.minecraftforge.items.wrapper.CombinedInvWrapper;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.capabilities.Capability;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.CollisionGetter;
import net.minecraft.world.level.storage.PrimaryLevelData;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Ghast;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.PlayerRideableJumping;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.control.JumpControl;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerListener;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HasCustomInventoryScreen;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.GameRules;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import tameable.spiders.entity.SpiderEntity;
import tameable.spiders.init.SpiderRules;
import tameable.spiders.init.TameableSpidersModEntities;
import tameable.spiders.init.TameableSpidersModItems;
import tameable.spiders.init.TameableSpidersModBlocks;
import tameable.spiders.network.TameableSpidersModVariables;
import tameable.spiders.world.inventory.SpiderInventoryMenu;
import tameable.spiders.block.entity.BedNorthBlockEntity;
import tameable.spiders.block.BedNorthBlock;
import tameable.spiders.goal.ClaimBedGoal;
import tameable.spiders.goal.SpiderSit;

import javax.annotation.Nullable;
import javax.annotation.Nonnull;
import io.netty.buffer.Unpooled;


public abstract class AbstractSpider extends TamableAnimal implements HasCustomInventoryScreen, PlayerRideableJumping, Enemy {
	public static final EntityDataAccessor<Boolean> SittingState = SynchedEntityData.defineId(AbstractSpider.class, EntityDataSerializers.BOOLEAN);
	public static final EntityDataAccessor<Boolean> SittingMode = SynchedEntityData.defineId(AbstractSpider.class, EntityDataSerializers.BOOLEAN);
	public static final EntityDataAccessor<Boolean> HasSaddle = SynchedEntityData.defineId(AbstractSpider.class, EntityDataSerializers.BOOLEAN);
	public static final EntityDataAccessor<Boolean> IsClimbing = SynchedEntityData.defineId(AbstractSpider.class, EntityDataSerializers.BOOLEAN);
	public static final EntityDataAccessor<Boolean> HasRespawned = SynchedEntityData.defineId(AbstractSpider.class, EntityDataSerializers.BOOLEAN);
	public static final EntityDataAccessor<Integer> Collar = SynchedEntityData.defineId(AbstractSpider.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Integer> HarvestTimer = SynchedEntityData.defineId(AbstractSpider.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Optional<BlockPos>> HomePos = SynchedEntityData.defineId(AbstractSpider.class, EntityDataSerializers.OPTIONAL_BLOCK_POS);
    protected final NonNullList<ItemStack> Inventory = NonNullList.withSize(9, ItemStack.EMPTY);
    protected BedNorthBlockEntity Home;
    protected EntityType Type;
    protected EntityType MimicType;
    protected Item SpawnEgg;
    protected boolean Climb;

	public AbstractSpider(EntityType<? extends AbstractSpider> type, Level world) {
		super(type, world);
		setMaxUpStep(0.6f);
		xpReward = 5;
		setNoAi(false);
		refreshDimensions();
		
		this.Type = type;
		this.SpawnEgg = this.isSpider() ? Items.SPIDER_SPAWN_EGG : Items.CAVE_SPIDER_SPAWN_EGG;
		this.MimicType = this.isSpider() ? EntityType.SPIDER : EntityType.CAVE_SPIDER;
		this.RefreshHealth(true);
	}

	public boolean isSpider() {
		return this instanceof SpiderEntity;
	}

	public boolean isCaveSpider() {
		return this instanceof CaveSpiderEntity;
	}

	public ResourceLocation getTexture(boolean Backside) {
		String location = "tameable_spiders:textures/entities/";
		if(this.isCaveSpider())
			location += "cave_";
		
		location += "spider";

		if(Backside)
			location += "_back";
		return new ResourceLocation(location + ".png");
	}

	public void RefreshHealth(boolean FullHeal) {
		float BaseHP = this.isSpider() ? 16f : 12f;
		
		GameRules.Key<GameRules.IntegerValue> TameBuff = this.isSpider() ? SpiderRules.HEALTH_BUFF : SpiderRules.HEALTH_CAVEBUFF;
		float TameHP = BaseHP + this.level().getLevelData().getGameRules().getInt(TameBuff);
		TameHP = Math.min(TameHP, 32f);
		
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(BaseHP);
		if (this.isTame())
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(TameHP);

		float MaxHealth = this.getMaxHealth();
		float Health = this.getHealth();
		
		if(this.isTame())
			Health = Health + (TameHP - BaseHP);
		Health = FullHeal ? MaxHealth : Math.min(Health, MaxHealth);
		
        this.setHealth(Health);
	}

    public Iterable<ItemStack> getInventorySlots() {
        return this.Inventory;
    }

    @Nullable
    @Override
    public ItemStack getPickResult() {
        return new ItemStack(this.SpawnEgg);
    }

	@Override
    public ResourceLocation getDefaultLootTable() {
        return MimicType.getDefaultLootTable();
    }

    public DyeColor getCollarColor() {
        return DyeColor.byId(this.entityData.get(Collar));
    }

    public void setCollarColor(DyeColor color) {
        this.entityData.set(Collar, color.getId());
    }

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(SittingState, false);
		this.entityData.define(SittingMode, false);
		this.entityData.define(HasSaddle, false);
		this.entityData.define(Collar, DyeColor.RED.getId());
		this.entityData.define(HarvestTimer, 6000);
      	this.entityData.define(IsClimbing, false);
      	this.entityData.define(HasRespawned, false);
        this.entityData.define(HomePos, Optional.empty());
	}

	@Override
	public void addAdditionalSaveData(CompoundTag compound) {
		super.addAdditionalSaveData(compound);
		compound.putBoolean("SittingState", this.entityData.get(SittingState));
		compound.putBoolean("SittingMode", this.entityData.get(SittingMode));
		compound.putBoolean("HasSaddle", this.entityData.get(HasSaddle));
		compound.putBoolean("HasRespawned", this.entityData.get(HasRespawned));
		compound.putInt("Collar", this.entityData.get(Collar));
		compound.putInt("HarvestTimer", this.entityData.get(HarvestTimer));
		compound.put("InventoryCustom", inventory.serializeNBT());
        this.GetHome().ifPresent(Home -> {
            compound.put("HomePos", NbtUtils.writeBlockPos(Home));
        });
	}

	@Override
	public void readAdditionalSaveData(CompoundTag compound) {
		super.readAdditionalSaveData(compound);
		this.RefreshHealth(false);
		
		if (compound.contains("SittingState"))
			this.entityData.set(SittingState, compound.getBoolean("SittingState"));
		if (compound.contains("SittingMode"))
			this.entityData.set(SittingMode, compound.getBoolean("SittingMode"));
		if (compound.contains("HasSaddle"))
			this.entityData.set(HasSaddle, compound.getBoolean("HasSaddle"));
		if (compound.contains("HasRespawned"))
			this.entityData.set(HasRespawned, compound.getBoolean("HasRespawned"));
		if (compound.contains("Collar"))
			this.entityData.set(Collar, compound.getInt("Collar"));
		if (compound.contains("HarvestTimer"))
			this.entityData.set(HarvestTimer, compound.getInt("HarvestTimer"));
		if (compound.get("InventoryCustom") instanceof CompoundTag inventoryTag)
			inventory.deserializeNBT(inventoryTag);
		if (compound.contains("HomePos"))
            this.SetHomePos(NbtUtils.readBlockPos(compound.getCompound("HomePos")));
	}
	
	public Optional<BlockPos> GetHome() {
        return this.entityData.get(HomePos);
    }

    private void TeleportHome() {
    	BlockPos Home = GetHomePos();
		Vec3 Pos = new Vec3(Home.getX() + 0.5, Home.getY() + 0.6875, Home.getZ() + 0.5);
    	
        this.setPos(Pos);
        this.getNavigation().moveTo(Home.getX(), Home.getY(), Home.getZ(), 0);
    }

	static class SpiderTargetGoal<T extends LivingEntity> extends NearestAttackableTargetGoal<T> {
    	public SpiderTargetGoal(AbstractSpider spider, Class<T> p_33833_) {
        	super(spider, p_33833_, true);
    	}

    	@Override
    	public boolean canUse() {
        	float f = this.mob.getLightLevelDependentMagicValue();
        	return f >= 0.5F ? false : super.canUse();
    	}
	}

	static class SpiderAttackGoal extends MeleeAttackGoal {
		public SpiderAttackGoal(AbstractSpider spider) {
    		super(spider, 1.0, true);
    	}

    	@Override
    	public boolean canUse() {
    		return super.canUse() && !this.mob.isVehicle();
    	}

    	@Override
    	public boolean canContinueToUse() {
        	float f = this.mob.getLightLevelDependentMagicValue();
        	if (f >= 0.5F && this.mob.getRandom().nextInt(100) == 0) {
            	this.mob.setTarget(null);
            	return false;
        	} else {
           	return super.canContinueToUse();
        	}
    	}
	}

    class SpiderPanicGoal extends PanicGoal {
        public SpiderPanicGoal(double p_203124_) {
            super(AbstractSpider.this, p_203124_);
        }

        @Override
        protected boolean shouldPanic() {
            return this.mob.isFreezing() || this.mob.isOnFire();
        }
    }

	@Override
	protected void registerGoals() {
		super.registerGoals();
		
        this.goalSelector.addGoal(1, new FloatGoal(this) {
			@Override
			public boolean canUse() {
				return super.canUse() && !AbstractSpider.this.isVehicle();
			}

			@Override
			public boolean canContinueToUse() {
				return super.canContinueToUse() && !AbstractSpider.this.isVehicle();
			}
		});

        this.goalSelector.addGoal(1, new AbstractSpider.SpiderPanicGoal(1.5) {
			@Override
			public boolean canUse() {
				return super.canUse() && !AbstractSpider.this.isVehicle();
			}

			@Override
			public boolean canContinueToUse() {
				return super.canContinueToUse() && !AbstractSpider.this.isVehicle();
			}
		});
		
        this.goalSelector.addGoal(2, new SpiderSit(this));
        
        this.goalSelector.addGoal(3, new LeapAtTargetGoal(this, 0.4F) {
			@Override
			public boolean canUse() {
				return super.canUse() && !AbstractSpider.this.isVehicle();
			}

			@Override
			public boolean canContinueToUse() {
				return super.canContinueToUse() && !AbstractSpider.this.isVehicle();
			}
		});
		
        this.goalSelector.addGoal(4, new SpiderAttackGoal(this));
        this.goalSelector.addGoal(6, new FollowOwnerGoal(this, 1.0, 10.0F, 2.0F, false));
        
        this.goalSelector.addGoal(7, new BreedGoal(this, 1.0) {
			@Override
			public boolean canUse() {
				return super.canUse() && !AbstractSpider.this.isVehicle() && AbstractSpider.this.level().getLevelData().getGameRules().getBoolean(SpiderRules.BREEDING);
			}

			@Override
			public boolean canContinueToUse() {
				return super.canContinueToUse() && !AbstractSpider.this.isVehicle() && AbstractSpider.this.level().getLevelData().getGameRules().getBoolean(SpiderRules.BREEDING);
			}
		});
        
        this.goalSelector.addGoal(8, new ClaimBedGoal(this, 1.0, 12));
        this.goalSelector.addGoal(9, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(10, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(11, new RandomLookAroundGoal(this));
        
        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this));

        this.targetSelector.addGoal(4, new SpiderTargetGoal<>(this, Player.class));
        this.targetSelector.addGoal(5, new SpiderTargetGoal<>(this, IronGolem.class));
	}

	@Override
   	protected PathNavigation createNavigation(Level world) {
    	return new WallClimberNavigation(this, world);
   	}

	@Override
   	protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
		float AdultHeight = this.isSpider() ? 0.65f : 0.45f;
		float BabyHeight = AdultHeight * 0.5f;
    	return this.isBaby() ? BabyHeight : AdultHeight;
  	}

	@Override
	public MobType getMobType() {
		return MobType.ARTHROPOD;
	}

	@Override
	public SoundEvent getAmbientSound() {
		return BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("entity.spider.ambient"));
	}

	@Override
	public void playStepSound(BlockPos pos, BlockState blockIn) {
		this.playSound(BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("entity.spider.step")), 0.15f, 1);
	}

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("entity.spider.hurt"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("entity.spider.death"));
	}
	
	@Override
	public void die(DamageSource source) {
		super.die(source);

		if(this.entityData.get(HasRespawned) == true)
		{
			this.dropEquipment();
		}
	}
	
	@Override
	protected void tickDeath()
	{
        ++this.deathTime;
        if (this.deathTime >= 20 && !this.level().isClientSide() && !this.isRemoved())
        {
            this.level().broadcastEntityEvent(this, (byte)60);
            if (this.level().getLevelData().getGameRules().getBoolean(SpiderRules.RESPAWN) && this.isTame())
			{
				if(this.level().getLevelData().getGameRules().getBoolean(SpiderRules.RESPAWN_BLOCK) && this.Home == null)
					this.remove(Entity.RemovalReason.KILLED);

				BlockPos respawnPos;
				if(this.Home != null)
				{
					respawnPos = this.GetHomePos();
				}
				else
				{
					respawnPos = this.level().getSharedSpawnPos();
				}
			
				this.setHealth(this.getMaxHealth());
				this.entityData.set(SittingMode, true);
				this.entityData.set(SittingState, true);
				this.entityData.set(HasRespawned, true);
				this.setPos(0, 9999, 0);
				this.setPos(9999, 9999, 9999);
				TeleportRespawn(respawnPos);
				this.deathTime = 0;
			}
			else
			{
				this.remove(Entity.RemovalReason.KILLED);
			}
        }
    }

	@Override
    public void remove(Entity.RemovalReason reason) {
        if(hasHome())
        	Home.RemoveOccupied();
        	
        super.remove(reason);
    }

    private void TeleportRespawn(BlockPos respawnPos)
    {
    	if(respawnPos == this.GetHomePos())
    	{
    		this.TeleportHome();
    	}
    	else
    	{
    		this.setPos(respawnPos.getX(), respawnPos.getY(), respawnPos.getZ());
			this.getNavigation().moveTo(respawnPos.getX(), respawnPos.getY(), respawnPos.getZ(), 0);
    	}
    }

    public boolean WillRespawn()
    {
    	if (this.level().getLevelData().getGameRules().getBoolean(SpiderRules.RESPAWN) && this.isTame())
		{
			if(this.level().getLevelData().getGameRules().getBoolean(SpiderRules.RESPAWN_BLOCK) && this.Home == null)
				return false;

			return true;
		}
		return false;
    }

    public float GetScale()
    {
    	float BabyScale = AdultScale() * 0.5f;
    	return isBaby() ? BabyScale : AdultScale();
    }

    public float AdultScale() {
    	return this.isSpider() ? 1f : 0.7f;
    }

    public float AdultSize() {
    	return this.isSpider() ? 1f : 0.55f;
    }

	@Override
    public boolean dismountsUnderwater() {
        return true;
    }

	@Override
	public boolean hurt(DamageSource damagesource, float amount) {
		if (damagesource.is(DamageTypes.FALL) && !this.level().getLevelData().getGameRules().getBoolean(SpiderRules.FALLDAMAGE))
			return false;
		return super.hurt(damagesource, amount);
	}

	@Override
    public boolean doHurtTarget(Entity entity) {
    	if(this.isSpider())
    		return super.doHurtTarget(entity);
        if (super.doHurtTarget(entity)) {
            if (entity instanceof LivingEntity target && (!this.isBaby() || this.level().getLevelData().getGameRules().getBoolean(SpiderRules.BABY_POISON)))
            {
                if (this.level().getDifficulty() == Difficulty.NORMAL) {
                    target.addEffect(new MobEffectInstance(MobEffects.POISON, 140, 0), this);
                } else if (this.level().getDifficulty() == Difficulty.HARD) {
                    target.addEffect(new MobEffectInstance(MobEffects.POISON, 300, 0), this);
                }
            }

            return true;
        } else {
            return false;
        }
    }

	@Override
	public SpawnGroupData finalizeSpawn(ServerLevelAccessor world, DifficultyInstance difficulty, MobSpawnType reason, @Nullable SpawnGroupData livingdata, @Nullable CompoundTag tag) {
		SpawnGroupData retval = super.finalizeSpawn(world, difficulty, reason, livingdata, tag);
		return retval;
	}

	@Override
    public void openCustomInventoryScreen(Player player) {
        if (!this.level().isClientSide && (!this.isVehicle() || this.hasPassenger(player)) && this.isTame() && this.level().getLevelData().getGameRules().getBoolean(SpiderRules.INVENTORY)) {
            this.openInventory(player);
        }
    }
    
    protected void openInventory (Player player) {
    	if (player instanceof ServerPlayer serverPlayer) {
			NetworkHooks.openScreen(serverPlayer, new MenuProvider() {
				@Override
				public Component getDisplayName() {
					return Component.literal("Spider");
				}

				@Override
				public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
					FriendlyByteBuf packetBuffer = new FriendlyByteBuf(Unpooled.buffer());
					packetBuffer.writeBlockPos(player.blockPosition());
					packetBuffer.writeByte(0);
					packetBuffer.writeVarInt(AbstractSpider.this.getId());
					return new SpiderInventoryMenu(id, inventory, packetBuffer);
				}
			}, buf -> {
				buf.writeBlockPos(player.blockPosition());
				buf.writeByte(0);
				buf.writeVarInt(this.getId());
			});
		}
    }

	private final ItemStackHandler inventory = new ItemStackHandler(10) {
		@Override
		public int getSlotLimit(int slot) {
			return 64;
		}
	};

	private final CombinedInvWrapper combined = new CombinedInvWrapper(inventory, new EntityHandsInvWrapper(this), new EntityArmorInvWrapper(this));

	@Override
	public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> capability, @Nullable Direction side) {
		if (this.isAlive() && capability == ForgeCapabilities.ITEM_HANDLER && side == null)
			return LazyOptional.of(() -> combined).cast();

		return super.getCapability(capability, side);
	}

	@Override
	protected void dropEquipment() {
		if(this.level().getLevelData().getGameRules().getBoolean(SpiderRules.KEEP_INVENTORY) && this.WillRespawn() == true)
			return;
		
		super.dropEquipment();
		for (int i = 0; i < inventory.getSlots(); ++i) {
			ItemStack itemstack = inventory.getStackInSlot(i);
			if (!itemstack.isEmpty() && !EnchantmentHelper.hasVanishingCurse(itemstack)) {
				ItemStack GroundItem = itemstack.copy();
				this.spawnAtLocation(GroundItem);
			}
			itemstack.setCount(0);
		}
	}

	@Override
	public InteractionResult mobInteract(Player sourceentity, InteractionHand hand) {
		ItemStack itemstack = sourceentity.getItemInHand(hand);
		InteractionResult retval = InteractionResult.sidedSuccess(this.level().isClientSide());
		Entity Rider = this.getPassengers().isEmpty() ? null : (Entity) this.getPassengers().get(0);
		
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		int age = this.getAge();
		Entity entity = this;
		Level world = this.level();
		Item item = itemstack.getItem();
		TameableSpidersModVariables.PlayerVariables _vars = sourceentity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables());

		if(_vars.AssigningHome == true)
		{
			MutableComponent Text = AssignHome(_vars, sourceentity);
    		sourceentity.displayClientMessage(Text, true);
    		_vars.AssigningHome = false;
			_vars.syncPlayerVariables(entity);
			return InteractionResult.SUCCESS;
		}
            
		if (item == this.SpawnEgg)
		{
            if (this.level() instanceof ServerLevel) {
                Optional<Mob> optional = ((SpawnEggItem)this.SpawnEgg).spawnOffspringFromSpawnEgg(sourceentity, this, (EntityType<? extends Mob>)this.getType(), (ServerLevel)this.level(), this.position(), itemstack);
                optional.ifPresent(mob -> this.onOffspringSpawnedFromEgg(sourceentity, mob));
                return optional.isPresent() ? InteractionResult.SUCCESS : InteractionResult.PASS;
            } else {
                return InteractionResult.CONSUME;
            }
        }
		else if (this.level().isClientSide())
		{
			retval = (this.isTame() && this.isOwnedBy(sourceentity) || itemstack.is(ItemTags.create(new ResourceLocation("spiderman318:rawmeat"))) ? InteractionResult.sidedSuccess(this.level().isClientSide()) : InteractionResult.PASS);
		}
		else if (Rider instanceof Player || Rider == null)
		{
			if (this.isTame())
			{	if (this.CanHarvest(item))
				{
					this.Harvest(world, x, y, z, sourceentity, hand, itemstack);
				}
				else if (item.isEdible() && this.isFood(itemstack) && this.getHealth() < this.getMaxHealth())
				{
					this.usePlayerItem(sourceentity, hand, itemstack);
					this.heal((float) item.getFoodProperties().getNutrition());
					retval = InteractionResult.sidedSuccess(this.level().isClientSide());
				}
				else if (this.isFood(itemstack) && this.getHealth() < this.getMaxHealth())
				{
					this.usePlayerItem(sourceentity, hand, itemstack);
					this.heal(4);
					retval = InteractionResult.sidedSuccess(this.level().isClientSide());
				}
				else if (item instanceof DyeItem dyeitem && this.isOwnedBy(sourceentity))
				{
					DyeColor dyecolor = dyeitem.getDyeColor();
                    if (dyecolor != this.getCollarColor()) {
                        this.setCollarColor(dyecolor);
                        if (!sourceentity.getAbilities().instabuild) {
                            itemstack.shrink(1);
                        }

                        return InteractionResult.SUCCESS;
                    }
				}
				else if (this.isFood(itemstack) && this.isBaby())
				{
                	this.usePlayerItem(sourceentity, hand, itemstack);
                	this.ageUp(getSpeedUpSecondsWhenFeeding(-age), true);
                	return InteractionResult.sidedSuccess(this.level().isClientSide);
				}
				else if (this.isFood(itemstack) && !this.isBaby() && this.canFallInLove())
				{
                	this.resetLove();
                	this.usePlayerItem(sourceentity, hand, itemstack);
                	this.setInLove(sourceentity);
                	return InteractionResult.SUCCESS;
				}
				else
				{
					if (!this.level().getLevelData().getGameRules().getBoolean(SpiderRules.INVENTORY) && this.level().getLevelData().getGameRules().getBoolean(SpiderRules.RIDABLE))
					{
						if (sourceentity.isShiftKeyDown() && itemstack.getItem() == Items.SADDLE && this.entityData.get(HasSaddle) == false)
						{
							this.inventory.insertItem(0, new ItemStack(Items.SADDLE), false);
                			this.usePlayerItem(sourceentity, hand, itemstack);
							this.UpdateSaddle();
						}
						else if (!sourceentity.isShiftKeyDown())
						{
							sourceentity.startRiding(this);
						}
						else if (this.isOwnedBy(sourceentity))
						{
							this.entityData.set(SittingMode, !this.entityData.get(SittingMode));
						}
					}
					else
					{
						if (sourceentity.isShiftKeyDown() && this.level().getLevelData().getGameRules().getBoolean(SpiderRules.INVENTORY))
						{
							openInventory(sourceentity);
						}
						else if (this.isOwnedBy(sourceentity))
						{
							this.entityData.set(SittingMode, !this.entityData.get(SittingMode));
						}
					}
				}
			}
			else if (this.isFood(itemstack) && (this.getTarget() != sourceentity))
			{
				this.usePlayerItem(sourceentity, hand, itemstack);
				if (this.random.nextInt(3) == 0)
				{
					this.setPersistenceRequired();
					this.tame(sourceentity);
					this.level().broadcastEntityEvent(this, (byte) 7);
					this.RefreshHealth(this.level().getLevelData().getGameRules().getBoolean(SpiderRules.FULLHEAL));

					if (sourceentity instanceof ServerPlayer _player) {
						Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("tameable:arachnid_ally"));
						AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
						if (!_ap.isDone()) {
							for (String criteria : _ap.getRemainingCriteria())
								_player.getAdvancements().award(_adv, criteria);
						}
					}
				}
				else
				{
					this.level().broadcastEntityEvent(this, (byte) 6);
				}
				
				retval = InteractionResult.sidedSuccess(this.level().isClientSide());
			}
			else
			{
				retval = super.mobInteract(sourceentity, hand);
			}
		}

		return retval;
	}

	@Override
    public boolean isFood(ItemStack itemstack) {
        return itemstack.getItem().isEdible() && itemstack.getFoodProperties(this).isMeat();
    }

    public MutableComponent AssignHome(TameableSpidersModVariables.PlayerVariables variables, Player assigner)
    {
    	Block block = variables.AssignHome.getBlock();
    	BlockPos pos = BlockPos.containing(variables.AssignX, variables.AssignY, variables.AssignZ);
    	Level world = this.level();
    	
    	if(block instanceof BedNorthBlock Bed)
    	{
    		BedNorthBlockEntity BedEntity = (BedNorthBlockEntity) world.getBlockEntity(pos);
			Block newBlock = level().getBlockState(BedEntity.getBlockPos()).getBlock();
			if(newBlock instanceof BedNorthBlock newBed)
			{
    			if(BedEntity.IsOccupied())
    				return Component.literal("Bed already Claimed");
    			if(hasHome())
    				return Component.literal("Target already has Home");
    			if(!isTame() || !isOwnedBy(assigner))
    				return Component.literal("You dont own Target");

    			StoreHome(BedEntity.getBlockPos());
    			return Component.literal("Target's Home set to Bed");
			}
    		
			return Component.literal("Bed no longer exists");
    	}

    	return Component.literal("Error: unknown outcome");
    }
    
	@Override
	public AgeableMob getBreedOffspring(ServerLevel serverWorld, AgeableMob ageable) 
	{	
		Entity retval = Type.create(serverWorld);
		AbstractSpider Spider = (AbstractSpider)retval;
		Spider.entityData.set(Collar, 5);
		Spider.tame((Player) this.getOwner());
		
		Spider.finalizeSpawn(serverWorld, serverWorld.getCurrentDifficultyAt(retval.blockPosition()), MobSpawnType.BREEDING, null, null);
		return Spider;
	}

	@Override
   	public void tick() {
      	super.tick();
      	if (!this.level().isClientSide)
         	this.setClimbing(this.canClimb());
   	}

   	public boolean canClimb() {
   		if(!this.isVehicle())
   			return this.horizontalCollision;
   		return this.horizontalCollision && this.Climb;
   	}
   	
	@Override
   	public boolean onClimbable() {
      	return this.isClimbing();
   	}

	@Override
	public void baseTick() {
		super.baseTick();

		Entity Spider = (Entity) this;
		boolean InLiquid = this.isInWaterOrBubble() == true || this.isInLava() == true;
		boolean Leashed = this.isLeashed();
		boolean Mounted = this.isVehicle();
		boolean Freezing = this.isFreezing();
		boolean OnFire = this.isOnFire();
		Level world = this.level();
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();

		if (this.isTame())
		{
			ItemStack StringSlot = new Object() {
				public ItemStack getItemStack(int sltid, Entity entity) {
					AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
					entity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
						_retval.set(capability.getStackInSlot(sltid).copy());
					});
					return _retval.get();
				}
			}.getItemStack(9, this);

			if(this.level().getLevelData().getGameRules().getBoolean(SpiderRules.PRODUCE_SILK))
			{
				this.entityData.set(HarvestTimer, Math.max(this.entityData.get(HarvestTimer) - 1, 0));
				if (this.entityData.get(HarvestTimer) == 0)
				{
					this.entityData.set(HarvestTimer, Mth.nextInt(RandomSource.create(), 0, 6000) + 6000);
					if (this.level().getLevelData().getGameRules().getBoolean(SpiderRules.INVENTORY))
					{
						{
							ItemStack _setstack = new ItemStack(TameableSpidersModItems.SILK.get()).copy();
							_setstack.setCount((int) (StringSlot.getCount() + 1));
							this.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
							if (capability instanceof IItemHandlerModifiable _modHandlerEntSetSlot)
								_modHandlerEntSetSlot.setStackInSlot(9, _setstack);
							});
						}
					}
					else
				{
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(TameableSpidersModItems.SILK.get()));
							entityToSpawn.setPickUpDelay(0);
							_level.addFreshEntity(entityToSpawn);
							world.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("entity.chicken.egg")), SoundSource.NEUTRAL, 1, 1);
						}
					}
				}
			}

			boolean SittingInterupted = InLiquid || Leashed || Mounted || Freezing || OnFire;
			if (this.isSitting() == true && (!this.entityData.get(SittingMode) || SittingInterupted))
			{
				this.entityData.set(SittingState, false);
			}
			else if (!this.isSitting() && this.entityData.get(SittingMode) && !SittingInterupted)
			{
				this.entityData.set(SittingState, true);
				this.getNavigation().moveTo(x, y, z, 0);
			}
		}
	}

	@Override
	protected void actuallyHurt(DamageSource source, float amount) {
		this.entityData.set(SittingMode, false);
		super.actuallyHurt(source, amount);
	}

	@Override
    public void makeStuckInBlock(BlockState blockstate, Vec3 vector3) {
        if (!blockstate.is(Blocks.COBWEB)) {
            super.makeStuckInBlock(blockstate, vector3);
        }
    }
	
	@Override
   	public boolean canBeAffected(MobEffectInstance Effect) {
      	if (Effect.getEffect() == MobEffects.POISON) {
         	return false;
      	} else {
         	return super.canBeAffected(Effect);
      	}
   	}
   	
   	public boolean isSitting() {
      	return this.entityData.get(SittingState);
   	}
   	
   	public void setSitting(boolean value) {
      	this.entityData.set(SittingMode, value);
   	}
   	
   	public boolean hasSaddle() {
      	return this.entityData.get(HasSaddle);
   	}

   	public void UpdateSaddle()
   	{
   		boolean SaddleEquipped = (new Object() {
			public ItemStack getItemStack(int sltid, Entity entity) {
				AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
				entity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
					_retval.set(capability.getStackInSlot(sltid).copy());
				});
				return _retval.get();
			}
		}.getItemStack(0, this)).getItem() == Items.SADDLE;

		if (SaddleEquipped != this.hasSaddle())
		{
			if (SaddleEquipped == true)
				this.level().playSound(null, this.blockPosition(), BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("entity.pig.saddle")), SoundSource.NEUTRAL, 1, 1);
			this.entityData.set(HasSaddle, SaddleEquipped);
		}
   	}
   	
   	public boolean hasHome() {
      	return Home != null && (this.level().getBlockEntity(this.GetHomePos()) instanceof BedNorthBlockEntity || this.level().isLoaded(this.GetHomePos()));
   	}

   	public void ResetHome()
   	{
   		this.entityData.set(HomePos, Optional.empty());
   		Home = null;
   	}
   	
   	public boolean isClimbing() {
      	return this.entityData.get(IsClimbing);
   	}

   	public void setClimbing(boolean Input) {
      	this.entityData.set(IsClimbing, Input);
   	}

	@Override
	public void travel(Vec3 dir) 
	{
		/*Entity entity = this.getPassengers().isEmpty() ? null : (Entity) this.getPassengers().get(0);
		
		if (this.isVehicle() && this.hasSaddle())
		{
			this.setYRot(entity.getYRot());
			this.yRotO = this.getYRot();
			this.setXRot(entity.getXRot() * 0.5F);
			this.setRot(this.getYRot(), this.getXRot());
			this.yBodyRot = entity.getYRot();
			this.yHeadRot = entity.getYRot();
			
			if (entity instanceof LivingEntity passenger) {
				float ZMove = passenger.zza;
				float XMove = passenger.xxa;
				
				super.travel(new Vec3(XMove, 0, ZMove));
			}

			double d0 = this.getX() - this.xo;
			double d1 = this.getY() - this.yo;
			double d2 = this.getZ() - this.zo;
			
			return;
		}*/
		
		super.travel(dir);
	}

	@Nullable
   	public LivingEntity getControllingPassenger() {
      	if (this.hasSaddle())
      	{
      		Entity entity = this.getFirstPassenger();
      		if(entity instanceof LivingEntity rider)
      			return rider;
      	}
      	
      	return null;
   	}

   	private void travelRidden(Player player, Vec3 dir) {
      	Vec3 vec3 = this.getRiddenInput(player, dir);
      	this.tickRidden(player, vec3);
      	if (this.isControlledByLocalInstance()) {
         	this.setSpeed(this.getRiddenSpeed(player));
         	this.travel(vec3);
      	} else {
         	this.calculateEntityAnimation(false);
         	this.setDeltaMovement(Vec3.ZERO);
         	this.tryCheckInsideBlocks();
      	}

   	}

	protected void tickRidden(Player player, Vec3 dir) {
      	super.tickRidden(player, dir);
      	this.setRot(player.getYRot(), player.getXRot() * 0.5F);
      	this.yRotO = this.yBodyRot = this.yHeadRot = this.getYRot();
   	}

   	protected Vec3 getRiddenInput(Player player, Vec3 dir) {
        float f = player.xxa * 0.5F;
        float f1 = player.zza;
        if (f1 <= 0.0F) {
           f1 *= 0.25F;
        }

    	return new Vec3((double)f, 0.0D, (double)f1);
   	}

   	protected float getRiddenSpeed(Player player) {
   		return this.getSpeed() * 0.4f;
    }

    public boolean canJump() {
        return false;
    }

    public void onPlayerJump(int strength) {
    }
    
    public void handleStartJump(int strength) {
    }

    public void handleStopJump() {
    }

	public boolean CanHarvest(Item item) {
		if(this.isSpider())
			return false;
		return !this.isBaby() && item == Items.GLASS_BOTTLE && this.level().getLevelData().getGameRules().getBoolean(SpiderRules.PRODUCE_VEMON);
	}
	
	public void Harvest(Level world, double x, double y, double z, Player sourceentity, InteractionHand hand, ItemStack itemstack) {
		if(this.isSpider())
			return;
		world.playSound(null, this.blockPosition(), BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("entity.cow.milk")), SoundSource.NEUTRAL, 1, 1);
        itemstack.shrink(1);

		ItemStack vemon = new ItemStack(TameableSpidersModItems.VEMON.get());
		vemon.setCount(1);
		ItemHandlerHelper.giveItemToPlayer(sourceentity, vemon);
	}

	@Override
	public EntityDimensions getDimensions(Pose pose) {
		return super.getDimensions(pose).scale(AdultSize());
	}

	public static void init() {
	}

	@Override
    public boolean canMate(Animal animal) {
		boolean VaildTarget = animal != this && this.isTame();
		boolean VaildSpecies = animal.getType().is(TagKey.create(Registries.ENTITY_TYPE, new ResourceLocation("spiderman318:spider")));
		boolean SameSpecies = animal.getClass() == this.getClass();
    	
		if(!VaildTarget || !VaildSpecies)
			return false;

		if(!SameSpecies && !this.level().getLevelData().getGameRules().getBoolean(SpiderRules.VARIANT_BREEDING))
			return false;
        
        AbstractSpider spider = (AbstractSpider)animal;
        if(!spider.isTame() || spider.isSitting())
        	return false;
        	
        return this.isInLove() && spider.isInLove();
    }

	@Override
    public boolean wantsToAttack(LivingEntity target, LivingEntity owner) {
        if (target instanceof Creeper || target instanceof Ghast) {
            return false;
        } else if (target instanceof SpiderEntity spider) {
            return !spider.isTame() || spider.getOwner() != owner;
        } else if (target instanceof Player && owner instanceof Player && !((Player)owner).canHarmPlayer((Player)target)) {
            return false;
        } else if (target instanceof AbstractHorse && ((AbstractHorse)target).isTamed()) {
            return false;
        } else {
            return !(target instanceof TamableAnimal) || !((TamableAnimal)target).isTame();
        }
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return this.isTame() && super.canBeLeashed(player);
    }
    
    public BlockPos GetHomePos()
    {
    	BlockPos Pos = new BlockPos(0, 0, 0);
    	Optional<BlockPos> Home = GetHome();
    	if(Home.isPresent())
    	{
    		return Home.get();
    	}
    	
    	return Pos;
    }
    
    public void SetHomePos(BlockPos pos)
    {
    	this.entityData.set(HomePos, Optional.of(pos));
    }

    public void StoreHome(BlockPos pos)
    {
    	BlockEntity block = this.level().getBlockEntity(pos);
    	if(block instanceof BedNorthBlockEntity Bed)
    	{
    		if(Bed.IsOccupied() == false)
    		{
    			Bed.SetOccupied(this, true);
    			this.SetHomePos(pos);
    			this.Home = Bed;
    		}
    	}
    }

    public void StoreHome(int x, int y, int z)
    {
    	BlockPos pos = new BlockPos(x, y, z);
    	BlockEntity block = this.level().getBlockEntity(pos);
    	if(block instanceof BedNorthBlockEntity Bed) {
        	if(!Bed.IsOccupied()) {
            	Bed.SetOccupied(this, true);
            	this.SetHomePos(pos);
    			this.Home = Bed;
        	}
    	}
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.3);
		builder = builder.add(Attributes.MAX_HEALTH, 16);
		builder = builder.add(Attributes.ARMOR, 0);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 2);
		builder = builder.add(Attributes.FOLLOW_RANGE, 16);
		return builder;
	}
}
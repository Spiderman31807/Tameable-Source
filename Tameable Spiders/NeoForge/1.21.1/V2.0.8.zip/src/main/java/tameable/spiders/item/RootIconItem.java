
package tameable.spiders.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class RootIconItem extends Item {
	public RootIconItem() {
		super(new Item.Properties().stacksTo(0));
	}
}

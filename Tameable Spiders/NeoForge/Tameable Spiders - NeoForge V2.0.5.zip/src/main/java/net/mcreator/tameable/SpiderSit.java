package net.mcreator.tameable.world.entity.ai.goal;

import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.TamableAnimal;

import net.mcreator.tameable.entity.AbstractSpider;

public class SpiderSit extends Goal {
    private final AbstractSpider spider;

    public SpiderSit(AbstractSpider p_25898_) {
        this.spider = p_25898_;
        this.setFlags(EnumSet.of(Goal.Flag.JUMP, Goal.Flag.MOVE));
    }

    @Override
    public boolean canContinueToUse() {
        return this.spider.isSitting();
    }

    @Override
    public boolean canUse() {
        if (!this.spider.isTame()) {
            return false;
        } else if (this.spider.isInWaterOrBubble()) {
            return false;
        } else if (!this.spider.onGround()) {
            return false;
        } else {
            LivingEntity livingentity = this.spider.getOwner();
            if (livingentity == null) {
                return true;
            } else {
                return this.spider.distanceToSqr(livingentity) < 144.0 && livingentity.getLastHurtByMob() != null ? false : this.spider.isSitting();
            }
        }
    }
}
package net.mcreator.tameable.world.entity.ai.goal;

import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MoveToBlockGoal;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;

import net.mcreator.tameable.block.entity.BedNorthBlockEntity;
import net.mcreator.tameable.entity.AbstractSpider;
import net.mcreator.tameable.init.TameableRules;

public class ClaimBedGoal extends MoveToBlockGoal {
    private final AbstractSpider spider;

    public ClaimBedGoal(AbstractSpider spider, double speed, int range) {
        super(spider, speed, range, 6);
        this.spider = spider;
        this.verticalSearchStart = 0;
        this.setFlags(EnumSet.of(Goal.Flag.JUMP, Goal.Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        return this.spider.isTame() && !this.spider.isSitting() && !this.spider.hasHome() && !this.spider.isVehicle() && super.canUse();
    }

    @Override
    public void tick() {
        super.tick();
        
        if (this.isReachedTarget()) {
            this.spider.StoreHome(this.blockPos);
            this.spider.setSitting(true);
        }
    }

    @Override
	protected boolean isValidTarget(LevelReader levelReader, BlockPos blockPos) {
    	BlockEntity blockEntity  = levelReader.getBlockEntity(blockPos);
    	if (blockEntity instanceof BedNorthBlockEntity Bed) {
        	return levelReader.isEmptyBlock(blockPos.above()) && !Bed.IsOccupied();
    	}
    	return false;
	}

    @Override
	public double acceptedDistance() {
        return 1.5;
    }
}

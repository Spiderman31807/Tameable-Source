package net.mcreator.tameablespiders.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;

import net.mcreator.tameablespiders.init.TameableSpidersModGameRules;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class Cave_Spider_PoisonProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getSource(), event.getEntity());
		}
	}

	public static void execute(LevelAccessor world, DamageSource damagesource, Entity entity) {
		execute(null, world, damagesource, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, DamageSource damagesource, Entity entity) {
		if (damagesource == null || entity == null)
			return;
		Entity attacker = null;
		attacker = damagesource.getDirectEntity();
		if (attacker instanceof CaveSpiderEntity && (!(attacker instanceof LivingEntity _livEnt2 && _livEnt2.isBaby())
				|| attacker instanceof LivingEntity _livEnt3 && _livEnt3.isBaby() && world.getLevelData().getGameRules().getBoolean(TameableSpidersModGameRules.CONFI_BABY_POISON))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.POISON, 140, 1));
		}
	}
}

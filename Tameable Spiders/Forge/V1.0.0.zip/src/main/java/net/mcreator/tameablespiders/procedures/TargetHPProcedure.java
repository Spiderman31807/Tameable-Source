package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

public class TargetHPProcedure {
	public static String execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return "";
		Entity found_entity = null;
		found_entity = HudTargetProcedure.execute(world, x, y, z, entity);
		return (found_entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) + "/" + (found_entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1);
	}
}

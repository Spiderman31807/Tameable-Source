package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Entity;

public class FollowOwnerProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return !Panic_In_SnowProcedure.execute(entity) && Not_SittingProcedure.execute(entity) && (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false);
	}
}

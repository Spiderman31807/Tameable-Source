
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package tameable.spiders.init;

import tameable.spiders.item.VemonItem;
import tameable.spiders.item.SilkItem;
import tameable.spiders.item.AdvancementiconstomachacheItem;
import tameable.spiders.item.AdvancementiconrootItem;
import tameable.spiders.item.AdvancementiconlocalguideItem;
import tameable.spiders.item.AdvancementiconinfestationItem;
import tameable.spiders.item.AdvancementiconexterminatorItem;
import tameable.spiders.item.AdvancementiconarachnophobiaItem;
import tameable.spiders.item.AdvancementiconallyItem;
import tameable.spiders.TameableSpidersMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

public class TameableSpidersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TameableSpidersMod.MODID);
	public static final RegistryObject<Item> ADVANCEMENTICONARACHNOPHOBIA = REGISTRY.register("advancementiconarachnophobia", () -> new AdvancementiconarachnophobiaItem());
	public static final RegistryObject<Item> ADVANCEMENTICONROOT = REGISTRY.register("advancementiconroot", () -> new AdvancementiconrootItem());
	public static final RegistryObject<Item> ADVANCEMENTICONALLY = REGISTRY.register("advancementiconally", () -> new AdvancementiconallyItem());
	public static final RegistryObject<Item> ADVANCEMENTICONLOCALGUIDE = REGISTRY.register("advancementiconlocalguide", () -> new AdvancementiconlocalguideItem());
	public static final RegistryObject<Item> ADVANCEMENTICONEXTERMINATOR = REGISTRY.register("advancementiconexterminator", () -> new AdvancementiconexterminatorItem());
	public static final RegistryObject<Item> ADVANCEMENTICONINFESTATION = REGISTRY.register("advancementiconinfestation", () -> new AdvancementiconinfestationItem());
	public static final RegistryObject<Item> ADVANCEMENTICONSTOMACHACHE = REGISTRY.register("advancementiconstomachache", () -> new AdvancementiconstomachacheItem());
	public static final RegistryObject<Item> SILK = REGISTRY.register("silk", () -> new SilkItem());
	public static final RegistryObject<Item> VEMON = REGISTRY.register("vemon", () -> new VemonItem());
	public static final RegistryObject<Item> BED_ITEM = block(TameableSpidersModBlocks.BED_ITEM);
	public static final RegistryObject<Item> BED_NORTH = block(TameableSpidersModBlocks.BED_NORTH);
	public static final RegistryObject<Item> BED_SOUTH = block(TameableSpidersModBlocks.BED_SOUTH);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}

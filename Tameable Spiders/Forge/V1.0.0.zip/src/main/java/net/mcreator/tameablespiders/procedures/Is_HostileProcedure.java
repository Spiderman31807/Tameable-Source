package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import net.mcreator.tameablespiders.entity.SpiderEntity;

public class Is_HostileProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return false;
		double hostile_at = 0;
		if (entity instanceof SpiderEntity) {
			hostile_at = 11;
		} else {
			hostile_at = 7;
		}
		return world.getMaxLocalRawBrightness(BlockPos.containing(x, y, z)) <= hostile_at && !(entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false);
	}
}

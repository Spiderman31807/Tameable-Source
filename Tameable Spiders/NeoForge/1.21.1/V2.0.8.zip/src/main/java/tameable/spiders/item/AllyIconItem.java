
package tameable.spiders.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AllyIconItem extends Item {
	public AllyIconItem() {
		super(new Item.Properties().stacksTo(0));
	}
}

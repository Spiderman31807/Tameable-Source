package net.mcreator.tameable.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class spider_saddle_sitting<T extends Entity> extends EntityModel<T> {
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("tameable", "spider_saddle_sitting"), "main");
	public final ModelPart head;

	public spider_saddle_sitting(ModelPart root) {
		this.head = root.getChild("head");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition head = partdefinition.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 15.0F, -3.0F));
		PartDefinition neck = head.addOrReplaceChild("neck", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.5F, 2.5F, -0.1484F, 0.0F, 0.0F));
		PartDefinition body = neck.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, -3.0F, 3.0F, -0.192F, 0.0F, 0.0F));
		PartDefinition Saddle = body.addOrReplaceChild("Saddle", CubeListBuilder.create().texOffs(27, 5).addBox(-5.0F, 0.4F, -1.6F, 10.0F, -1.0F, 16.0F, new CubeDeformation(0.5F)), PartPose.offset(0.0F, -0.9F, -0.5F));
		PartDefinition Top_r1 = Saddle.addOrReplaceChild("Top_r1",
				CubeListBuilder.create().texOffs(24, -2).addBox(-10.0F, -4.1F, -5.0F, -1.0F, 10.0F, 10.0F, new CubeDeformation(0.5F)).texOffs(24, -2).addBox(1.0F, -4.1F, -5.0F, -1.0F, 10.0F, 10.0F, new CubeDeformation(0.5F)),
				PartPose.offsetAndRotation(5.0F, 5.4F, 5.4F, 1.5708F, 0.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 64, 32);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		head.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}

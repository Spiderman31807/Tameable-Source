package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import net.mcreator.tameablespiders.entity.SpiderEntity;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;

public class Spider_LootProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, DamageSource damagesource, Entity entity) {
		if (damagesource == null || entity == null)
			return;
		Entity killer = null;
		double string = 0;
		double eyes = 0;
		double looting = 0;
		boolean spawn_xp = false;
		ItemStack temp_item = ItemStack.EMPTY;
		if (!(entity instanceof LivingEntity _livEnt0 && _livEnt0.isBaby())) {
			killer = damagesource.getEntity();
			if (killer instanceof ServerPlayer _player) {
				Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("minecraft:adventure/kill_a_mob"));
				AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
				if (!_ap.isDone()) {
					for (String criteria : _ap.getRemainingCriteria())
						_player.getAdvancements().award(_adv, criteria);
				}
			}
			spawn_xp = (entity instanceof SpiderEntity
					? (entity instanceof SpiderEntity _datEntI ? _datEntI.getEntityData().get(SpiderEntity.DATA_Eligible_Loot) : 0)
					: (entity instanceof CaveSpiderEntity _datEntI ? _datEntI.getEntityData().get(CaveSpiderEntity.DATA_Eligible_Loot) : 0)) > 0;
			if (EnchantmentHelper.getItemEnchantmentLevel(Enchantments.MOB_LOOTING, (killer instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)) != 0
					|| EnchantmentHelper.getItemEnchantmentLevel(Enchantments.MOB_LOOTING, (killer instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)) != 0) {
				looting = Math.max((killer instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getEnchantmentLevel(Enchantments.MOB_LOOTING),
						(killer instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getEnchantmentLevel(Enchantments.MOB_LOOTING));
			} else {
				looting = 0;
			}
			string = Mth.nextInt(RandomSource.create(), 0, (int) (2 + looting));
			if (Mth.nextDouble(RandomSource.create(), 0, 1) > 2 / (looting + 3)) {
				eyes = Mth.nextInt(RandomSource.create(), 1, (int) (1 + looting));
			} else {
				eyes = 0;
			}
			if (string > 0) {
				temp_item = new ItemStack(Items.STRING);
				temp_item.setCount((int) string);
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, temp_item);
					entityToSpawn.setPickUpDelay(0);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			if (eyes > 0) {
				temp_item = new ItemStack(Items.SPIDER_EYE);
				temp_item.setCount((int) eyes);
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, temp_item);
					entityToSpawn.setPickUpDelay(0);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			if (spawn_xp) {
				if (world instanceof ServerLevel _level)
					_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 5));
			}
		}
	}
}

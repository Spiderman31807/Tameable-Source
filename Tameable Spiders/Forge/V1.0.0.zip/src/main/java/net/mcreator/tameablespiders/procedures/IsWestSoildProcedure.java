package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class IsWestSoildProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return false;
		boolean is_soild = false;
		double West_X = 0;
		BlockState West_Block = Blocks.AIR.defaultBlockState();
		is_soild = true;
		West_X = x - (entity.getBbWidth() + 0.1);
		West_Block = (world.getBlockState(BlockPos.containing(West_X, y, z)));
		if (West_Block.getBlock() instanceof LiquidBlock || !world.getBlockState(BlockPos.containing(West_X, y, z)).isFaceSturdy(world, BlockPos.containing(West_X, y, z), Direction.SOUTH)) {
			is_soild = false;
		} else {
			if (West_Block.getBlock() == Blocks.POWDER_SNOW) {
				is_soild = false;
			}
		}
		return is_soild;
	}
}

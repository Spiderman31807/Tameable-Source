package tameable.spiders.procedures;

import tameable.spiders.network.TameableSpidersModVariables;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.tags.TagKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

public class UnlockarachnophobiaProcedure {
	public static void execute(DamageSource damagesource, Entity entity) {
		if (damagesource == null || entity == null)
			return;
		if ((damagesource.getEntity()) instanceof Player && entity.getType().is(TagKey.create(Registries.ENTITY_TYPE, new ResourceLocation("spiderman318:spider")))) {
			{
				double _setval = ((damagesource.getEntity()).getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables())).SpiderKills + 1;
				(damagesource.getEntity()).getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.SpiderKills = _setval;
					capability.syncPlayerVariables((damagesource.getEntity()));
				});
			}
			if (((damagesource.getEntity()).getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables())).SpiderKills == 100) {
				if ((damagesource.getEntity()) instanceof ServerPlayer _player) {
					Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("tameable_spiders:arachnophobia"));
					AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
					if (!_ap.isDone()) {
						for (String criteria : _ap.getRemainingCriteria())
							_player.getAdvancements().award(_adv, criteria);
					}
				}
			} else if (((damagesource.getEntity()).getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables())).SpiderKills == 1000) {
				if ((damagesource.getEntity()) instanceof ServerPlayer _player) {
					Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("tameable_spiders:exterminator"));
					AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
					if (!_ap.isDone()) {
						for (String criteria : _ap.getRemainingCriteria())
							_player.getAdvancements().award(_adv, criteria);
					}
				}
			}
		}
	}
}

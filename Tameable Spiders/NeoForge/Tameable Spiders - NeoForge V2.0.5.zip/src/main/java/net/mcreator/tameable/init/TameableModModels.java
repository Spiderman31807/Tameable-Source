
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tameable.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.tameable.client.model.spider_sitting;
import net.mcreator.tameable.client.model.spider_saddle_stand;
import net.mcreator.tameable.client.model.spider_saddle_sitting;
import net.mcreator.tameable.client.model.spider_big_head;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class TameableModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(spider_saddle_stand.LAYER_LOCATION, spider_saddle_stand::createBodyLayer);
		event.registerLayerDefinition(spider_sitting.LAYER_LOCATION, spider_sitting::createBodyLayer);
		event.registerLayerDefinition(spider_saddle_sitting.LAYER_LOCATION, spider_saddle_sitting::createBodyLayer);
		event.registerLayerDefinition(spider_big_head.LAYER_LOCATION, spider_big_head::createBodyLayer);
	}
}

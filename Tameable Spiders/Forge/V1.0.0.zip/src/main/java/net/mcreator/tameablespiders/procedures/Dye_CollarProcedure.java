package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.level.GameType;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.client.Minecraft;

import net.mcreator.tameablespiders.entity.SpiderEntity;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;

public class Dye_CollarProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		Entity hand_of = null;
		hand_of = sourceentity;
		if (entity instanceof SpiderEntity) {
			if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BONE_MEAL
					|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.WHITE_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 0);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LIGHT_GRAY_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 1);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.GRAY_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 2);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.INK_SAC
					|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BLACK_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 3);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.RED_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 4);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.ORANGE_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 5);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.YELLOW_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 6);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LIME_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 7);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.GREEN_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 8);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.COCOA_BEANS
					|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BROWN_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 9);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.PINK_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 10);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.MAGENTA_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 11);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.PURPLE_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 12);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LAPIS_LAZULI
					|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BLUE_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 13);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.CYAN_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 14);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LIGHT_BLUE_DYE) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 15);
			}
		} else {
			if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BONE_MEAL
					|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.WHITE_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 0);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LIGHT_GRAY_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 1);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.GRAY_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 2);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.INK_SAC
					|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BLACK_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 3);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.RED_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 4);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.ORANGE_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 5);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.YELLOW_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 6);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LIME_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 7);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.GREEN_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 8);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.COCOA_BEANS
					|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BROWN_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 9);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.PINK_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 10);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.MAGENTA_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 11);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.PURPLE_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 12);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LAPIS_LAZULI
					|| (hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BLUE_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 13);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.CYAN_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 14);
			} else if ((hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.LIGHT_BLUE_DYE) {
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 15);
			}
		}
		if (!(new Object() {
			public boolean checkGamemode(Entity _ent) {
				if (_ent instanceof ServerPlayer _serverPlayer) {
					return _serverPlayer.gameMode.getGameModeForPlayer() == GameType.CREATIVE;
				} else if (_ent.level().isClientSide() && _ent instanceof Player _player) {
					return Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()) != null && Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()).getGameMode() == GameType.CREATIVE;
				}
				return false;
			}
		}.checkGamemode(hand_of))) {
			(hand_of instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).shrink(1);
		}
	}
}

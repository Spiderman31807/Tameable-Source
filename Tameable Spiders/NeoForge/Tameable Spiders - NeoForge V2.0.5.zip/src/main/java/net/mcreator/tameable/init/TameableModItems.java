
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tameable.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.bus.api.IEventBus;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.tameable.item.VemonItem;
import net.mcreator.tameable.item.SilkItem;
import net.mcreator.tameable.item.AdvancementIconStomachAcheItem;
import net.mcreator.tameable.item.AdvancementIconRootItem;
import net.mcreator.tameable.item.AdvancementIconLocalGuideItem;
import net.mcreator.tameable.item.AdvancementIconInfestationItem;
import net.mcreator.tameable.item.AdvancementIconExterminatorItem;
import net.mcreator.tameable.item.AdvancementIconArachnophobiaItem;
import net.mcreator.tameable.item.AdvancementIconAllyItem;
import net.mcreator.tameable.TameableMod;

public class TameableModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, TameableMod.MODID);
	public static final DeferredHolder<Item, Item> ADVANCEMENT_ICON_ARACHNOPHOBIA = REGISTRY.register("advancement_icon_arachnophobia", () -> new AdvancementIconArachnophobiaItem());
	public static final DeferredHolder<Item, Item> ADVANCEMENT_ICON_ROOT = REGISTRY.register("advancement_icon_root", () -> new AdvancementIconRootItem());
	public static final DeferredHolder<Item, Item> ADVANCEMENT_ICON_ALLY = REGISTRY.register("advancement_icon_ally", () -> new AdvancementIconAllyItem());
	public static final DeferredHolder<Item, Item> SILK = REGISTRY.register("silk", () -> new SilkItem());
	public static final DeferredHolder<Item, Item> ADVANCEMENT_ICON_LOCAL_GUIDE = REGISTRY.register("advancement_icon_local_guide", () -> new AdvancementIconLocalGuideItem());
	public static final DeferredHolder<Item, Item> ADVANCEMENT_ICON_EXTERMINATOR = REGISTRY.register("advancement_icon_exterminator", () -> new AdvancementIconExterminatorItem());
	public static final DeferredHolder<Item, Item> ADVANCEMENT_ICON_INFESTATION = REGISTRY.register("advancement_icon_infestation", () -> new AdvancementIconInfestationItem());
	public static final DeferredHolder<Item, Item> VEMON = REGISTRY.register("vemon", () -> new VemonItem());
	public static final DeferredHolder<Item, Item> ADVANCEMENT_ICON_STOMACH_ACHE = REGISTRY.register("advancement_icon_stomach_ache", () -> new AdvancementIconStomachAcheItem());
	public static final DeferredHolder<Item, Item> BED_ITEM = block(TameableModBlocks.BED_ITEM);
	public static final DeferredHolder<Item, Item> BED_NORTH = block(TameableModBlocks.BED_NORTH);
	public static final DeferredHolder<Item, Item> BED_SOUTH = block(TameableModBlocks.BED_SOUTH);

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}

	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tameable.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.tameable.block.BedSouthBlock;
import net.mcreator.tameable.block.BedNorthBlock;
import net.mcreator.tameable.block.BedItemBlock;
import net.mcreator.tameable.TameableMod;

public class TameableModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, TameableMod.MODID);
	public static final DeferredHolder<Block, Block> BED_ITEM = REGISTRY.register("bed_item", () -> new BedItemBlock());
	public static final DeferredHolder<Block, Block> BED_NORTH = REGISTRY.register("bed_north", () -> new BedNorthBlock());
	public static final DeferredHolder<Block, Block> BED_SOUTH = REGISTRY.register("bed_south", () -> new BedSouthBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}

package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.tameablespiders.entity.SpiderEntity;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;

public class Panic_In_SnowProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity instanceof SpiderEntity _datEntI ? _datEntI.getEntityData().get(SpiderEntity.DATA_In_Snow) : 0) > 0 || (entity instanceof CaveSpiderEntity _datEntI ? _datEntI.getEntityData().get(CaveSpiderEntity.DATA_In_Snow) : 0) > 0;
	}
}

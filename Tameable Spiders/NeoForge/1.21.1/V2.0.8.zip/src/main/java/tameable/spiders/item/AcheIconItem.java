
package tameable.spiders.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AcheIconItem extends Item {
	public AcheIconItem() {
		super(new Item.Properties().stacksTo(0));
	}
}

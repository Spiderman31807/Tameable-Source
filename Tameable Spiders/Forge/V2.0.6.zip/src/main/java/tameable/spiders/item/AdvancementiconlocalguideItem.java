
package tameable.spiders.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AdvancementiconlocalguideItem extends Item {
	public AdvancementiconlocalguideItem() {
		super(new Item.Properties().stacksTo(0).rarity(Rarity.COMMON));
	}
}

package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class IsEastSoildProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return false;
		boolean is_soild = false;
		double East_X = 0;
		BlockState East_Block = Blocks.AIR.defaultBlockState();
		is_soild = true;
		East_X = x + entity.getBbWidth() + 0.1;
		East_Block = (world.getBlockState(BlockPos.containing(East_X, y, z)));
		if (East_Block.getBlock() instanceof LiquidBlock || !world.getBlockState(BlockPos.containing(East_X, y, z)).isFaceSturdy(world, BlockPos.containing(East_X, y, z), Direction.SOUTH)) {
			is_soild = false;
		} else {
			if (East_Block.getBlock() == Blocks.POWDER_SNOW) {
				is_soild = false;
			}
		}
		return is_soild;
	}
}


package tameable.spiders.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AdvancementiconexterminatorItem extends Item {
	public AdvancementiconexterminatorItem() {
		super(new Item.Properties().stacksTo(0).rarity(Rarity.COMMON));
	}
}

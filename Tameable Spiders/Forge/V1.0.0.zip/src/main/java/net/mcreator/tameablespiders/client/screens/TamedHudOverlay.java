
package net.mcreator.tameablespiders.client.screens;

import org.checkerframework.checker.units.qual.h;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.Minecraft;

import net.mcreator.tameablespiders.procedures.TargetHPProcedure;
import net.mcreator.tameablespiders.procedures.IsHudTargetProcedure;
import net.mcreator.tameablespiders.procedures.HudTargetProcedure;

@Mod.EventBusSubscriber({Dist.CLIENT})
public class TamedHudOverlay {
	@SubscribeEvent(priority = EventPriority.NORMAL)
	public static void eventHandler(RenderGuiEvent.Pre event) {
		int w = event.getWindow().getGuiScaledWidth();
		int h = event.getWindow().getGuiScaledHeight();
		Level world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		Player entity = Minecraft.getInstance().player;
		if (entity != null) {
			world = entity.level();
			x = entity.getX();
			y = entity.getY();
			z = entity.getZ();
		}
		if (IsHudTargetProcedure.execute(world, x, y, z, entity)) {
			event.getGuiGraphics().drawString(Minecraft.getInstance().font,

					TargetHPProcedure.execute(world, x, y, z, entity), w - 68, h - 27, -1, false);
			if (HudTargetProcedure.execute(world, x, y, z, entity) instanceof LivingEntity livingEntity) {
				InventoryScreen.renderEntityInInventoryFollowsAngle(event.getGuiGraphics(), w - 48, h - 32, 30, 1f, 0, livingEntity);
			}
		}
	}
}

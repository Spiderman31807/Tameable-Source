package tameable.spiders.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SpiderRules {
	public static GameRules.Key<GameRules.IntegerValue> SPAWN_RATE = GameRules.register("TameableSpiders_SpawnRate", GameRules.Category.MOBS, GameRules.IntegerValue.create(33));
	public static GameRules.Key<GameRules.IntegerValue> BABY_RATE = GameRules.register("TameableSpiders_BabyRate", GameRules.Category.MOBS, GameRules.IntegerValue.create(5));
	public static GameRules.Key<GameRules.IntegerValue> HEALTH_BUFF = GameRules.register("TameableSpiders_TameBuff", GameRules.Category.MOBS, GameRules.IntegerValue.create(8));
	public static GameRules.Key<GameRules.IntegerValue> HEALTH_CAVEBUFF = GameRules.register("TameableSpiders_CaveTameBuff", GameRules.Category.MOBS, GameRules.IntegerValue.create(8));
	public static GameRules.Key<GameRules.BooleanValue> BREEDING = GameRules.register("TameableSpiders_Breeding", GameRules.Category.MOBS, GameRules.BooleanValue.create(true));
	public static GameRules.Key<GameRules.BooleanValue> RIDABLE = GameRules.register("TameableSpiders_Ridable", GameRules.Category.MOBS, GameRules.BooleanValue.create(true));
	public static GameRules.Key<GameRules.BooleanValue> INVENTORY = GameRules.register("TameableSpiders_Inventory", GameRules.Category.MOBS, GameRules.BooleanValue.create(true));
	public static GameRules.Key<GameRules.BooleanValue> BABY_POISON = GameRules.register("TameableSpiders_BabyPoison", GameRules.Category.MOBS, GameRules.BooleanValue.create(false));
	public static GameRules.Key<GameRules.BooleanValue> PRODUCE_SILK = GameRules.register("TameableSpiders_ProduceSilk", GameRules.Category.MOBS, GameRules.BooleanValue.create(true));
	public static GameRules.Key<GameRules.BooleanValue> PRODUCE_VEMON = GameRules.register("TameableSpiders_ProduceVemon", GameRules.Category.MOBS, GameRules.BooleanValue.create(true));
	public static GameRules.Key<GameRules.BooleanValue> RESPAWN = GameRules.register("TameableSpiders_Respawn", GameRules.Category.MOBS, GameRules.BooleanValue.create(false));
	public static GameRules.Key<GameRules.BooleanValue> RESPAWN_BLOCK = GameRules.register("TameableSpiders_RespawnBlock", GameRules.Category.MOBS, GameRules.BooleanValue.create(false));
	public static GameRules.Key<GameRules.BooleanValue> KEEP_INVENTORY = GameRules.register("TameableSpiders_KeepInventory", GameRules.Category.MOBS, GameRules.BooleanValue.create(false));
	public static GameRules.Key<GameRules.BooleanValue> FALLDAMAGE = GameRules.register("TameableSpiders_FallDamage", GameRules.Category.MOBS, GameRules.BooleanValue.create(true));
	public static GameRules.Key<GameRules.BooleanValue> VARIANT_BREEDING = GameRules.register("TameableSpiders_VariantBreeding", GameRules.Category.MOBS, GameRules.BooleanValue.create(false));
	public static GameRules.Key<GameRules.BooleanValue> FULLHEAL = GameRules.register("TameableSpiders_TameFullHeal", GameRules.Category.MOBS, GameRules.BooleanValue.create(true));
}

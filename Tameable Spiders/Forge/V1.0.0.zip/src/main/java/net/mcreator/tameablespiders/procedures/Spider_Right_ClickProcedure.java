package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.tameablespiders.network.TameableSpidersModVariables;
import net.mcreator.tameablespiders.entity.SpiderEntity;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;

public class Spider_Right_ClickProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		boolean can_dye = false;
		if ((entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) && sourceentity == (entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null)
				&& !((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BEEF
						|| (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.PORKCHOP
						|| (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.MUTTON
						|| (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.CHICKEN
						|| (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.RABBIT)) {
			if (Can_DyeProcedure.execute(entity, sourceentity) == true) {
				Dye_CollarProcedure.execute(entity, sourceentity);
			} else if (sourceentity.isShiftKeyDown()) {
				if (((sourceentity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables())).watch_HP).equals(entity.getStringUUID())) {
					{
						String _setval = "";
						sourceentity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.watch_HP = _setval;
							capability.syncPlayerVariables(sourceentity);
						});
					}
				} else {
					{
						String _setval = entity.getStringUUID();
						sourceentity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.watch_HP = _setval;
							capability.syncPlayerVariables(sourceentity);
						});
					}
				}
			} else {
				if ((entity instanceof SpiderEntity _datEntL16 && _datEntL16.getEntityData().get(SpiderEntity.DATA_Trying_To_Sit)) == true
						|| (entity instanceof CaveSpiderEntity _datEntL17 && _datEntL17.getEntityData().get(CaveSpiderEntity.DATA_Trying_To_Sit)) == true) {
					if (entity instanceof SpiderEntity _datEntSetL)
						_datEntSetL.getEntityData().set(SpiderEntity.DATA_Trying_To_Sit, false);
					if (entity instanceof CaveSpiderEntity _datEntSetL)
						_datEntSetL.getEntityData().set(CaveSpiderEntity.DATA_Trying_To_Sit, false);
				} else {
					if (entity instanceof SpiderEntity _datEntSetL)
						_datEntSetL.getEntityData().set(SpiderEntity.DATA_Trying_To_Sit, true);
					if (entity instanceof CaveSpiderEntity _datEntSetL)
						_datEntSetL.getEntityData().set(CaveSpiderEntity.DATA_Trying_To_Sit, true);
				}
			}
		}
	}
}

package net.mcreator.tameablespiders.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.AnimalTameEvent;

import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.tameablespiders.network.TameableSpidersModVariables;
import net.mcreator.tameablespiders.entity.SpiderEntity;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class Join_TeamProcedure {
	@SubscribeEvent
	public static void onEntityTamed(AnimalTameEvent event) {
		execute(event, event.getAnimal(), event.getTamer());
	}

	public static void execute(Entity entity, Entity sourceentity) {
		execute(null, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		{
			Entity _entityTeam = entity;
			PlayerTeam _pt = _entityTeam.level().getScoreboard().getPlayerTeam(((sourceentity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables())).team));
			if (_pt != null) {
				if (_entityTeam instanceof Player _player)
					_entityTeam.level().getScoreboard().addPlayerToTeam(_player.getGameProfile().getName(), _pt);
				else
					_entityTeam.level().getScoreboard().addPlayerToTeam(_entityTeam.getStringUUID(), _pt);
			}
		}
		if (entity instanceof SpiderEntity _datEntSetI)
			_datEntSetI.getEntityData().set(SpiderEntity.DATA_Collar_Color, 4);
		if (entity instanceof CaveSpiderEntity _datEntSetI)
			_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Collar_Color, 4);
		if (entity instanceof SpiderEntity _datEntSetS)
			_datEntSetS.getEntityData().set(SpiderEntity.DATA_ID,
					("My Tame " + Math.round((sourceentity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables())).ID_Increase)));
		if (entity instanceof CaveSpiderEntity _datEntSetS)
			_datEntSetS.getEntityData().set(CaveSpiderEntity.DATA_ID,
					("My Tame " + Math.round((sourceentity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables())).ID_Increase)));
		{
			double _setval = (sourceentity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TameableSpidersModVariables.PlayerVariables())).ID_Increase + 1;
			sourceentity.getCapability(TameableSpidersModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.ID_Increase = _setval;
				capability.syncPlayerVariables(sourceentity);
			});
		}
	}
}

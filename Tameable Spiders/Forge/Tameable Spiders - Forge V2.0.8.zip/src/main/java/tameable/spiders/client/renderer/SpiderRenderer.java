
package tameable.spiders.client.renderer;

import tameable.spiders.renderer.TamableSpiderRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

public class SpiderRenderer extends TamableSpiderRenderer {
	public SpiderRenderer(EntityRendererProvider.Context context) {
		super(context);
	}
}
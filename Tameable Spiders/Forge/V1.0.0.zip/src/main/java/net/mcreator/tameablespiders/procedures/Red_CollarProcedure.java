package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.tameablespiders.entity.SpiderEntity;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;

public class Red_CollarProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		boolean return_logic = false;
		double collar_color = 0;
		collar_color = 4;
		return_logic = false;
		if (entity instanceof SpiderEntity) {
			if ((entity instanceof SpiderEntity _datEntI ? _datEntI.getEntityData().get(SpiderEntity.DATA_Collar_Color) : 0) == collar_color) {
				return_logic = true;
			}
		} else {
			if ((entity instanceof CaveSpiderEntity _datEntI ? _datEntI.getEntityData().get(CaveSpiderEntity.DATA_Collar_Color) : 0) == collar_color) {
				return_logic = true;
			}
		}
		if (entity instanceof SpiderEntity) {
			if (entity instanceof SpiderEntity _datEntL4 && _datEntL4.getEntityData().get(SpiderEntity.DATA_Sitting)) {
				return_logic = false;
			}
		} else {
			if (entity instanceof CaveSpiderEntity _datEntL5 && _datEntL5.getEntityData().get(CaveSpiderEntity.DATA_Sitting)) {
				return_logic = false;
			}
		}
		return return_logic;
	}
}

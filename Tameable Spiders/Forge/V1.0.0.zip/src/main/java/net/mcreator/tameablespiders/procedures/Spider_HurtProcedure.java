package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;

import net.mcreator.tameablespiders.entity.SpiderEntity;
import net.mcreator.tameablespiders.entity.CaveSpiderEntity;

public class Spider_HurtProcedure {
	public static void execute(DamageSource damagesource, Entity entity) {
		if (damagesource == null || entity == null)
			return;
		if (damagesource.is(DamageTypes.FREEZE)) {
			if (entity instanceof SpiderEntity _datEntSetI)
				_datEntSetI.getEntityData().set(SpiderEntity.DATA_In_Snow, 20);
			if (entity instanceof CaveSpiderEntity _datEntSetI)
				_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_In_Snow, 20);
		} else {
			if (entity instanceof SpiderEntity _datEntSetL)
				_datEntSetL.getEntityData().set(SpiderEntity.DATA_Trying_To_Sit, false);
			if (entity instanceof CaveSpiderEntity _datEntSetL)
				_datEntSetL.getEntityData().set(CaveSpiderEntity.DATA_Trying_To_Sit, false);
			if ((damagesource.getEntity()) instanceof Player
					|| (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) && ((damagesource.getEntity()) instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof Player) {
				if (entity instanceof SpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SpiderEntity.DATA_Eligible_Loot, 100);
				if (entity instanceof CaveSpiderEntity _datEntSetI)
					_datEntSetI.getEntityData().set(CaveSpiderEntity.DATA_Eligible_Loot, 100);
			}
		}
	}
}

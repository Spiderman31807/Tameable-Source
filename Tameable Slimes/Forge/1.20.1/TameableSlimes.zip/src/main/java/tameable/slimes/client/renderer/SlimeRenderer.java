package tameable.slimes.client.renderer;

import tameable.slimes.renderer.TameableSlimeRenderer;

import net.minecraft.client.renderer.entity.EntityRendererProvider;

public class SlimeRenderer extends TameableSlimeRenderer {
	public SlimeRenderer(EntityRendererProvider.Context context) {
		super(context);
	}
}
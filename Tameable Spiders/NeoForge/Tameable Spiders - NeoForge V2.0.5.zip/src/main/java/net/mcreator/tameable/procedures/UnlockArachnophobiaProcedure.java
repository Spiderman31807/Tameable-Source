package net.mcreator.tameable.procedures;

import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.tags.TagKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import net.mcreator.tameable.network.TameableModVariables;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class UnlockArachnophobiaProcedure {
	@SubscribeEvent
	public static void onEntityDeath(LivingDeathEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getSource(), event.getEntity());
		}
	}

	public static void execute(DamageSource damagesource, Entity entity) {
		execute(null, damagesource, entity);
	}

	private static void execute(@Nullable Event event, DamageSource damagesource, Entity entity) {
		if (damagesource == null || entity == null)
			return;
		if ((damagesource.getEntity()) instanceof Player && entity.getType().is(TagKey.create(Registries.ENTITY_TYPE, new ResourceLocation("spiderman318:spider")))) {
			{
				TameableModVariables.PlayerVariables _vars = (damagesource.getEntity()).getData(TameableModVariables.PLAYER_VARIABLES);
				_vars.SpiderKills = (damagesource.getEntity()).getData(TameableModVariables.PLAYER_VARIABLES).SpiderKills + 1;
				_vars.syncPlayerVariables((damagesource.getEntity()));
			}
			if ((damagesource.getEntity()).getData(TameableModVariables.PLAYER_VARIABLES).SpiderKills == 100) {
				if ((damagesource.getEntity()) instanceof ServerPlayer _player) {
					AdvancementHolder _adv = _player.server.getAdvancements().get(new ResourceLocation("tameable:arachnophobia"));
					if (_adv != null) {
						AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
						if (!_ap.isDone()) {
							for (String criteria : _ap.getRemainingCriteria())
								_player.getAdvancements().award(_adv, criteria);
						}
					}
				}
			} else if ((damagesource.getEntity()).getData(TameableModVariables.PLAYER_VARIABLES).SpiderKills == 1000) {
				if ((damagesource.getEntity()) instanceof ServerPlayer _player) {
					AdvancementHolder _adv = _player.server.getAdvancements().get(new ResourceLocation("tameable:exterminator"));
					if (_adv != null) {
						AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
						if (!_ap.isDone()) {
							for (String criteria : _ap.getRemainingCriteria())
								_player.getAdvancements().award(_adv, criteria);
						}
					}
				}
			}
		}
	}
}

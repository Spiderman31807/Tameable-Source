package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

public class Wall_ClimbProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean north_soild = false;
		boolean south_soild = false;
		boolean east_soild = false;
		boolean west_soild = false;
		if (Not_SittingProcedure.execute(entity) && (entity.getDeltaMovement().x() != 0 || entity.getDeltaMovement().z() != 0)) {
			north_soild = IsNorthSoildProcedure.execute(world, x, y, z, entity);
			south_soild = IsSouthSoildProcedure.execute(world, x, y, z, entity);
			east_soild = IsEastSoildProcedure.execute(world, x, y, z, entity);
			west_soild = IsWestSoildProcedure.execute(world, x, y, z, entity);
			if (north_soild == true || south_soild == true || east_soild == true || west_soild == true) {
				entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x()), 0.05, (entity.getDeltaMovement().z())));
				entity.fallDistance = 0;
			}
		}
	}
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tameable.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.tameable.client.renderer.SpiderRenderer;
import net.mcreator.tameable.client.renderer.CaveSpiderRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class TameableModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(TameableModEntities.SPIDER.get(), SpiderRenderer::new);
		event.registerEntityRenderer(TameableModEntities.CAVE_SPIDER.get(), CaveSpiderRenderer::new);
	}
}

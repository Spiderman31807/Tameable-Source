package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class IsNorthSoildProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return false;
		BlockState north_block = Blocks.AIR.defaultBlockState();
		double North_Z = 0;
		boolean is_soild = false;
		is_soild = true;
		North_Z = z - (entity.getBbWidth() + 0.1);
		north_block = (world.getBlockState(BlockPos.containing(x, y, North_Z)));
		if (north_block.getBlock() instanceof LiquidBlock || !world.getBlockState(BlockPos.containing(x, y, North_Z)).isFaceSturdy(world, BlockPos.containing(x, y, North_Z), Direction.SOUTH)) {
			is_soild = false;
		} else {
			if (north_block.getBlock() == Blocks.POWDER_SNOW) {
				is_soild = false;
			}
		}
		return is_soild;
	}
}

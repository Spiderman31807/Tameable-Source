package net.mcreator.tameable.block.entity;

import net.neoforged.neoforge.items.wrapper.SidedInvWrapper;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.ContainerHelper;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.tameable.init.TameableModBlockEntities;
import net.mcreator.tameable.entity.AbstractSpider;
import net.mcreator.tameable.block.BedNorthBlock;

import javax.annotation.Nullable;

import java.util.stream.IntStream;
import java.util.Optional;
import java.util.UUID;

public class BedNorthBlockEntity extends RandomizableContainerBlockEntity implements WorldlyContainer {
	private NonNullList<ItemStack> stacks = NonNullList.<ItemStack>withSize(9, ItemStack.EMPTY);
	private final SidedInvWrapper handler = new SidedInvWrapper(this, null);
	private Boolean IsOccupied;
	private UUID OccupiedUUID;

	public BedNorthBlockEntity(BlockPos position, BlockState state) {
		super(TameableModBlockEntities.BED_NORTH.get(), position, state);
		
		OccupiedUUID = null;
		IsOccupied = false;
	}

	@Override
	public void load(CompoundTag compound) {
		super.load(compound);
		
        if (compound.hasUUID("Occupied")){
            OccupiedUUID = compound.getUUID("Occupied");
			IsOccupied = true;
        }

        UpdateAttached();
		UpdateOccupied();
	}

    @Override
    protected void saveAdditional(CompoundTag compound) {
        super.saveAdditional(compound);
        if(IsOccupied)
        	compound.putUUID("Occupied", OccupiedUUID);
    }
	

	@Override
	public ClientboundBlockEntityDataPacket getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}

	@Override
	public CompoundTag getUpdateTag() {
		return this.saveWithFullMetadata();
	}

	@Override
	public int getContainerSize() {
		return stacks.size();
	}

	@Override
	public boolean isEmpty() {
		for (ItemStack itemstack : this.stacks)
			if (!itemstack.isEmpty())
				return false;
		return true;
	}

	@Override
	public Component getDefaultName() {
		return Component.literal("bed_north");
	}

	@Override
	public int getMaxStackSize() {
		return 64;
	}

	@Override
	public AbstractContainerMenu createMenu(int id, Inventory inventory) {
		return ChestMenu.threeRows(id, inventory);
	}

	@Override
	public Component getDisplayName() {
		return Component.literal("Spider Bed");
	}

	@Override
	protected NonNullList<ItemStack> getItems() {
		return this.stacks;
	}

	@Override
	protected void setItems(NonNullList<ItemStack> stacks) {
		this.stacks = stacks;
	}

	@Override
	public boolean canPlaceItem(int index, ItemStack stack) {
		return true;
	}

	@Override
	public int[] getSlotsForFace(Direction side) {
		return IntStream.range(0, this.getContainerSize()).toArray();
	}

	@Override
	public boolean canPlaceItemThroughFace(int index, ItemStack stack, @Nullable Direction direction) {
		return this.canPlaceItem(index, stack);
	}

	@Override
	public boolean canTakeItemThroughFace(int index, ItemStack stack, Direction direction) {
		return true;
	}

	public SidedInvWrapper getItemHandler() {
		return handler;
	}
	
	
	public void SetOccupied(Entity mob, Boolean bool)
	{
		OccupiedUUID = mob.getUUID();
		IsOccupied = true;
		UpdateOccupied();
		if(bool == true)
			UpdateAttached();
	}
	
	public void RemoveOccupied()
	{
		OccupiedUUID = null;
		IsOccupied = false;
		UpdateOccupied();
		UpdateAttached();
	}

	public Entity GetOccupied()
	{
		if (IsOccupied == true)
		{
			if(getLevel() instanceof ServerLevel server)
        		return server.getEntity(OccupiedUUID);
    	}
    	return null;
	}

	public UUID GetOccupiedUUID()
	{
		if (IsOccupied == true)
		{
        	return OccupiedUUID;
    	}
    	return null;
	}

	public boolean IsOccupied()
	{
		return IsOccupied;
	}

	public void UpdateOccupied()
	{
		Optional<UUID> value = IsOccupied ? Optional.of(OccupiedUUID) : Optional.empty();
		((BedNorthBlock) getBlockState().getBlock()).UpdateOccupied(value);
	}

	public void UpdateAttached()
	{
		if(getLevel() == null)
			return;
		((BedNorthBlock) getBlockState().getBlock()).UpdateAttached(IsOccupied, getLevel(), getBlockPos());
	}
}

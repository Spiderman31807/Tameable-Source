package net.mcreator.tameablespiders.procedures;

import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

public class Spider_Follow_AdultProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return entity instanceof LivingEntity _livEnt0 && _livEnt0.isBaby() && !(entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false);
	}
}
